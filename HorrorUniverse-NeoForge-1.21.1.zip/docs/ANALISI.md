# Analisi, regole e coerenza — Horror Universe (modulo 1)

## Fase A — Architettura
- **Versione/strumenti**: Minecraft 1.21.1, NeoForge 21.1.220, Java 21, ModDevGradle 2.0.141 (verificati online sul template ufficiale).
  Scelta fatta dove il prompt non specificava la versione: è la più diffusa per NeoForge e quella con più mod compatibili.
  Se giochi su 26.x dimmelo: il porting cambia molte API (render, SavedData, Identifier).
- **Pacchetti** (`com.horroruniverse`): `core` (regole armi, tabella boss, effetti, utilità), `data` (progressione e memoria salvate nel mondo),
  `config`, `registry`, `entity`, `item`, `event` (scheduler + direttore eventi), `command`, `client` (renderer).
- **Sistemi condivisi**: `BossRules` (tabella vulnerabilità), `WeaponUtil` (attacco da scheda), `AbstractHorrorBoss` (barra, registrazione colpi,
  abbandono), `HorrorDirector` (eventi), `HorrorSavedData/PlayerProfile` (memoria limitata a 48 voci, flag, relazioni), `HorrorEffects` (effetti bloccabili dal Frutto).
- **Registrazione colpi (Parte 9.5)**: arma valida + forma/fase corretta + vulnerabilità aperta + colpo riuscito + nessuna invulnerabilità +
  niente doppio conteggio (i-frame di Minecraft: il danno fisso per colpo speciale = salute massima / colpi richiesti).
- **Prestazioni**: eventi ogni 40 tick per giocatore (non a ogni tick), cooldown e probabilità, tetto ai servitori (`maxMinionsPerFight`), cloni limitati,
  nessuna struttura rigenerata, nessun salvataggio frequente, ogni boss ha una condizione di fine (vittoria o abbandono dopo `abandonSeconds`).
- **Limiti tecnici dichiarati**: nessuna compilazione/test; texture procedurali; modelli = geometria del giocatore; nessun suono personalizzato;
  scuotimento schermo e overlay jumpscare non implementati (il jumpscare è titolo + suono, disattivabile).

## Fase B — Tabella Custode (implementato)
| Livello | Attivazione | Meccanica | Vulnerabilità | Vittoria | Ricompensa |
|---|---|---|---|---|---|
| 1 Guardiano | Sigillo | 3 ondate zombie (3/4/5), spada di legno, confusione, ritirata | Normale; arma L3/L6 = 1 colpo | Sconfiggerlo (scompare) | 2 frammenti, 2 pane, Sigillo |
| 2 Contatto | Sigillo | 3 contatti reali (clic destro ≤3.8 blocchi, 50 tick fra due), teletrasporti con segnale, zombie occhi bianchi (max 4 comparse) | Non attaccabile; zombie: L3=2, L6=1 | 3 contatti validi | 3 frammenti, Sigillo |
| 3 Scettro | Sigillo | fulmini telegrafati, archi, zone cariche, 3 servitori, 3 fasi | Normale; L3=2, L6=1 | Sconfiggerlo | Scettro, Sigillo, 4 frammenti |
| 4 Supremo | Sigillo | come L3 + effetti negativi + creature vanilla | Soglia attacco > 7 (netherite 8); L3=3, L6=1 | Scelta finale salvata nel mondo | Uccidi: Lama del Fulmine · Risparmia: Occhio del Rituale |
| 5 Rituale | Occhio del Rituale su Enderman (L3 completato, Custode vivo) | teletrasporti, finestre, Enderman, cloni, lancio, fulmini End, Occhi di Ender temporanei | Rituale: solo 10 Perle del Rituale in finestra | 10 colpi validi | Frutto dell'Eden, frammenti, Mele Lunari |

Servitori: Guardiano Pallido (debole alle spalle ×1.75, resistente di fronte ×0.6), Cavaliere del Fulmine (dopo la scarica è stordito, ×2),
Sentinella dell'End (colpirla le impedisce di scappare per 3 s).

## Tabella regole armi (verificata)
Hit richiesti = (arma L3 / arma L6). Vedi anche `/horror rules`.
| Forma | Tipo | L3 / L6 | Nota |
|---|---|---|---|
| Custode L1 / zombie L2 / L3 | Normale | 1/1 · 2/1 · 2/1 | prompt 9.4 |
| Custode L4 | Soglia >7 | 3/1 | netherite (8) passa, diamante (7) no |
| Custode L5 | Rituale | — | solo perle |
| Corrotto L1-2 / L3 / L4 / L5 | Invuln. speciale / Cond. / Temporanea / Cond. | 2/1 · 3/1 · 1/1 · 4/2 | prompt 9.4 |
| Clone 404 / Entity 404 L7 | Normale / Cond. | 4/2 · 20/10 | prompt 9.4 |
| Entity 404 L5, L6 | Cond. | 6/3, 12/6 | **PROPOSTA** (vuoto del prompt) |
| Uomo Magico L4 | Soglia ≥7 + condizione | — | spada di diamante dopo aver esaurito l'energia |

## Controllo di coerenza: contraddizioni e vuoti trovati (nessuna regola cambiata in silenzio)
- **C1 — Soglia e spada di diamante.** La soglia "attacco superiore a 7" (9.1) esclude la spada di diamante (attacco 7), ma l'Arcimago (5.6) si uccide
  con la spada di diamante. *Soluzione applicata:* soglia per forma — Custode L4 stretta (> 7), Arcimago inclusiva (≥ 7). Modificabile in `BossRules`.
- **C2 — Corrotto L1/L2 "non attaccabile" (3.3, 3.4) ma 9.4 dà 2 colpi (L3) e 1 colpo (L6).** *Soluzione:* le armi normali sono respinte,
  solo le due armi speciali bypassano l'immunità con quei numeri.
- **C3 — Entity 404 L1, L2, L5, L6 senza numeri in 9.4** (L3/L4 "dipende dall'arma", L7 = 20/10, clone 4/2). *Proposta:* L5 = 6/3, L6 = 12/6
  (fra clone e livello 7), L4 = 3 colpi con l'arma L3 (par. 4.6). Marcate PROPOSTA nella tabella, da confermare.
- **C4 — Tre armi anti-404** (arma L3, "nuova arma" del L5, arma L6) ma solo due con numeri. *Soluzione:* l'arma del L5 resta un'arma di supporto
  contro le sentinelle, fuori dalla tabella dei colpi.
- **C5 — Armi non ancora ottenibili.** Custode L1 ha regole per armi che arrivano molto dopo (404 L3/L6): valgono per le riprese e i test.
  Ricette **provvisorie** con materiali vanilla (Lama della Piaga: slime + netherite + bastone; Spada Meteorica: netherite + stella del Nether + bastone)
  finché non c'è il modulo Entity 404.
- **C6 — Gerarchia 8.1.** Verificata: Custode L4 (3/1) ≈ Corrotto L3 (3/1); Corrotto L5 (4/2) > Custode L4; Corrotto L5 = Clone (4/2);
  404 L6 (12/6, proposta) > clone; 404 L7 (20/10) ≫ L6. Il Custode L5 non ha numeri comparabili (10 perle): resta una regola narrativa
  ("leggermente più pericoloso del L4"), non un confronto di colpi.
- **C7 — Effetti estremi** (morte permanente narrativa, distruzione del mondo, morte in Creativa): nessun conflitto, ma nel modulo 404 andranno
  implementati solo come stato interno, mai toccando salvataggi, e disattivabili da config.

## Fuori portata di questo modulo (dichiarato)
Corrotto (statue, corruzione, artefatto), Entity 404 (livelli 1-7, clone, piaga, dimensione), Uomo Magico, Steve, boss fight dell'Osservatore,
dimensioni e strutture, suoni originali, scoperta degli spawner, alleanze persistenti oltre ai punteggi di relazione, opzioni di config per
funzioni non ancora presenti (dimensioni, morte permanente, distruzione del mondo).

## Prossimi moduli proposti
2) Corrotto + artefatto anti-oscurità · 3) Entity 404 L1-L4 + piaga · 4) Entity 404 L5-L7 + dimensione + clone · 5) Uomo Magico · 6) Steve · 7) Osservatore + interazioni fra entità.
