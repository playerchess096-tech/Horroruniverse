#!/usr/bin/env python3
"""Genera texture, modelli, lingue (it/en), ricette e pack.mcmeta di Horror Universe.
Uso:  python3 tools/generate_assets.py   (richiede Pillow)  -- rigenera tutto in src/main/resources."""
import json, os, random
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", "src", "main", "resources"))
ASSETS = os.path.join(ROOT, "assets", "horroruniverse")
DATA = os.path.join(ROOT, "data", "horroruniverse")
MOD = "horroruniverse"


def out(path, data=None, image=None, text=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if image is not None:
        image.save(path)
    elif data is not None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)


# ------------------------------------------------------------------ skin 64x64 (layout giocatore)
def noisy(c, amt, rnd):
    d = rnd.randint(-amt, amt)
    return tuple(max(0, min(255, v + d)) for v in c[:3]) + (255,)


def fill(img, box, color, rnd, amt=6):
    x0, y0, x1, y1 = box
    for y in range(y0, y1):
        for x in range(x0, x1):
            img.putpixel((x, y), noisy(color, amt, rnd))


def make_skin(name, skin, body, legs, eyes, accent=None, hair=None, mouth=(40, 20, 20)):
    rnd = random.Random(name)
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    fill(img, (0, 0, 32, 16), skin, rnd)                    # testa
    if hair:
        fill(img, (8, 0, 24, 8), hair, rnd)                 # sopra e lato superiore
        fill(img, (0, 8, 32, 10), hair, rnd)
    fill(img, (16, 16, 40, 32), body, rnd)                  # busto
    fill(img, (40, 16, 56, 32), body, rnd)                  # braccio destro
    fill(img, (40, 28, 56, 32), skin, rnd)
    fill(img, (0, 16, 16, 32), legs, rnd)                   # gamba destra
    fill(img, (32, 48, 48, 64), body, rnd)                  # braccio sinistro
    fill(img, (32, 60, 48, 64), skin, rnd)
    fill(img, (16, 48, 32, 64), legs, rnd)                  # gamba sinistra
    for (x, y) in [(9, 11), (10, 11), (9, 12), (10, 12), (13, 11), (14, 11), (13, 12), (14, 12)]:
        img.putpixel((x, y), tuple(eyes) + (255,))
    for x in (11, 12):
        img.putpixel((x, 14), tuple(mouth) + (255,))
    if accent:
        for y in range(20, 32):
            img.putpixel((23, y), tuple(accent) + (255,))
            img.putpixel((24, y), tuple(accent) + (255,))
        for x in range(20, 28):
            img.putpixel((x, 31), tuple(accent) + (255,))
    out(os.path.join(ASSETS, "textures", "entity", name + ".png"), image=img)


WHITE = (255, 255, 255)
SKINS = {
    "keeper_l1": dict(skin=(200, 190, 175), body=(150, 100, 60), legs=(120, 80, 50), eyes=WHITE),
    "keeper_l2": dict(skin=(225, 220, 215), body=(235, 235, 235), legs=(205, 205, 205), eyes=WHITE),
    "keeper_l3": dict(skin=(200, 200, 210), body=(40, 50, 90), legs=(30, 35, 70), eyes=WHITE, accent=(120, 200, 255)),
    "keeper_l4": dict(skin=(235, 235, 240), body=(240, 240, 245), legs=(220, 220, 228), eyes=WHITE, accent=(230, 190, 60)),
    "keeper_l5": dict(skin=(120, 100, 160), body=(25, 10, 40), legs=(18, 8, 30), eyes=WHITE, accent=(200, 100, 255)),
    "minion_pale_guardian": dict(skin=(190, 190, 190), body=(165, 165, 150), legs=(140, 140, 130), eyes=WHITE, accent=(90, 90, 90)),
    "minion_lightning_knight": dict(skin=(180, 180, 190), body=(70, 80, 110), legs=(55, 60, 90), eyes=(255, 255, 140), accent=(120, 200, 255)),
    "minion_end_sentinel": dict(skin=(60, 30, 80), body=(20, 10, 30), legs=(15, 8, 25), eyes=(255, 80, 255)),
    "white_eyed_zombie": dict(skin=(110, 140, 100), body=(60, 70, 110), legs=(50, 50, 120), eyes=WHITE),
    "apparition_keeper": dict(skin=(225, 225, 225), body=(235, 235, 235), legs=(215, 215, 215), eyes=WHITE),
    "apparition_corrupted": dict(skin=(30, 30, 40), body=(15, 15, 25), legs=(10, 10, 20), eyes=(190, 40, 40)),
    "apparition_entity404": dict(skin=(60, 160, 60), body=(230, 230, 230), legs=(210, 210, 210), eyes=(120, 255, 120)),
    "apparition_mage": dict(skin=(210, 180, 160), body=(50, 20, 80), legs=(35, 15, 60), eyes=(190, 120, 255), accent=(150, 90, 220)),
    "apparition_steve": dict(skin=(190, 140, 110), body=(0, 170, 170), legs=(60, 60, 150), eyes=(60, 60, 200), hair=(70, 45, 25)),
    "apparition_observer": dict(skin=(12, 12, 12), body=(10, 10, 10), legs=(8, 8, 8), eyes=WHITE),
}
for n, kw in SKINS.items():
    make_skin(n, **kw)


# ------------------------------------------------------------------ icone 16x16
def new16():
    return Image.new("RGBA", (16, 16), (0, 0, 0, 0))


def sword(blade, edge, guard, handle):
    im = new16()
    d = ImageDraw.Draw(im)
    d.line([(13, 2), (6, 9)], fill=blade, width=2)
    d.line([(14, 3), (7, 10)], fill=edge, width=1)
    d.line([(3, 8), (8, 13)], fill=guard, width=1)
    d.line([(5, 10), (2, 13)], fill=handle, width=2)
    d.point((1, 14), fill=guard)
    return im


def icon_pale_fragment():
    im = new16(); d = ImageDraw.Draw(im)
    d.polygon([(8, 1), (12, 6), (10, 14), (5, 10), (4, 5)], fill=(225, 225, 232, 255), outline=(150, 150, 165, 255))
    d.line([(8, 3), (8, 11)], fill=(255, 255, 255, 255))
    d.point((6, 6), fill=(255, 255, 255, 255))
    return im


def icon_sigil():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([1, 1, 14, 14], fill=(35, 35, 55, 255), outline=(210, 210, 225, 255))
    d.ellipse([3, 5, 12, 10], fill=(245, 245, 250, 255), outline=(255, 255, 255, 255))
    d.ellipse([6, 6, 9, 9], fill=(255, 255, 255, 255))
    d.line([(7, 1), (7, 3)], fill=(210, 210, 225, 255))
    d.line([(7, 12), (7, 14)], fill=(210, 210, 225, 255))
    return im


def icon_eden():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([2, 3, 13, 14], fill=(245, 205, 60, 255), outline=(255, 250, 190, 255))
    d.ellipse([4, 5, 7, 8], fill=(255, 245, 170, 255))
    d.line([(8, 3), (8, 1)], fill=(110, 80, 40, 255))
    d.polygon([(9, 2), (13, 1), (11, 4)], fill=(80, 190, 70, 255))
    return im


def icon_scepter():
    im = new16(); d = ImageDraw.Draw(im)
    d.line([(3, 14), (10, 7)], fill=(110, 80, 50, 255), width=2)
    d.ellipse([9, 1, 14, 6], fill=(120, 200, 255, 255), outline=(230, 250, 255, 255))
    d.point((12, 3), fill=(255, 255, 255, 255))
    for p in [(15, 0), (8, 0), (15, 7), (7, 3)]:
        d.point(p, fill=(255, 255, 120, 255))
    return im


def icon_pearl():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([2, 2, 13, 13], fill=(30, 140, 130, 255), outline=(10, 70, 80, 255))
    d.ellipse([4, 4, 7, 7], fill=(160, 255, 240, 255))
    d.arc([5, 5, 11, 11], 0, 270, fill=(150, 70, 200, 255))
    return im


def icon_ritual_eye():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([1, 4, 14, 11], fill=(210, 235, 225, 255), outline=(60, 160, 140, 255))
    d.ellipse([5, 5, 10, 10], fill=(60, 30, 90, 255))
    d.point((6, 6), fill=(255, 255, 255, 255))
    d.line([(7, 1), (7, 3)], fill=(150, 70, 200, 255))
    d.line([(7, 12), (7, 14)], fill=(150, 70, 200, 255))
    return im


def icon_lens():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([1, 1, 11, 11], fill=(170, 220, 245, 150), outline=(190, 190, 210, 255))
    d.line([(10, 10), (14, 14)], fill=(110, 80, 50, 255), width=2)
    d.point((4, 4), fill=(255, 255, 255, 255))
    return im


def icon_bread():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([1, 4, 14, 12], fill=(220, 190, 130, 255), outline=(150, 110, 60, 255))
    for p in [(5, 7), (8, 6), (10, 8), (7, 9)]:
        d.point(p, fill=(245, 245, 235, 255))
    return im


def icon_moon_apple():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([2, 3, 13, 14], fill=(175, 200, 255, 255), outline=(90, 110, 190, 255))
    d.ellipse([4, 5, 8, 9], fill=(235, 242, 255, 255))
    d.line([(8, 3), (8, 1)], fill=(100, 80, 60, 255))
    d.polygon([(9, 2), (13, 1), (11, 4)], fill=(90, 150, 220, 255))
    return im


def icon_cookie():
    im = new16(); d = ImageDraw.Draw(im)
    d.ellipse([2, 2, 13, 13], fill=(200, 150, 90, 255), outline=(130, 90, 50, 255))
    for p in [(5, 5), (8, 4), (10, 7), (6, 9), (9, 10)]:
        d.point(p, fill=(150, 80, 210, 255))
    return im


ICONS = {
    "pale_fragment": icon_pale_fragment(), "keeper_sigil": icon_sigil(), "eden_fruit": icon_eden(),
    "electric_scepter": icon_scepter(), "ritual_pearl": icon_pearl(), "ritual_eye": icon_ritual_eye(),
    "truth_lens": icon_lens(), "pale_bread": icon_bread(), "moon_apple": icon_moon_apple(), "rune_cookie": icon_cookie(),
    "plague_blade": sword((90, 200, 90, 255), (50, 140, 60, 255), (60, 60, 60, 255), (90, 60, 40, 255)),
    "meteor_blade": sword((255, 120, 40, 255), (120, 40, 20, 255), (50, 40, 40, 255), (80, 50, 40, 255)),
    "lightning_blade": sword((150, 220, 255, 255), (255, 240, 120, 255), (70, 70, 90, 255), (90, 60, 40, 255)),
}
for name, im in ICONS.items():
    out(os.path.join(ASSETS, "textures", "item", name + ".png"), image=im)

HANDHELD = {"plague_blade", "meteor_blade", "lightning_blade", "electric_scepter"}
for name in ICONS:
    parent = "minecraft:item/handheld" if name in HANDHELD else "minecraft:item/generated"
    out(os.path.join(ASSETS, "models", "item", name + ".json"),
        data={"parent": parent, "textures": {"layer0": MOD + ":item/" + name}})

# icone effetti (18x18)
shock = Image.new("RGBA", (18, 18), (0, 0, 0, 0)); d = ImageDraw.Draw(shock)
d.polygon([(10, 1), (4, 10), (8, 10), (6, 17), (14, 7), (9, 7)], fill=(255, 240, 110, 255), outline=(120, 190, 255, 255))
out(os.path.join(ASSETS, "textures", "mob_effect", "shock.png"), image=shock)
eden = Image.new("RGBA", (18, 18), (0, 0, 0, 0)); d = ImageDraw.Draw(eden)
d.ellipse([2, 3, 15, 16], fill=(245, 205, 60, 255), outline=(255, 250, 190, 255))
d.ellipse([5, 6, 8, 9], fill=(255, 245, 170, 255))
d.polygon([(9, 2), (14, 0), (12, 4)], fill=(80, 190, 70, 255))
out(os.path.join(ASSETS, "textures", "mob_effect", "eden_ward.png"), image=eden)

# ------------------------------------------------------------------ ricette (formato 1.21.1)
def ing(i):
    return {"item": i}


def shapeless(name, items, result, count=1):
    out(os.path.join(DATA, "recipe", name + ".json"), data={
        "type": "minecraft:crafting_shapeless", "category": "misc",
        "ingredients": [ing(i) for i in items], "result": {"id": result, "count": count}})


def shaped(name, pattern, key, result, count=1):
    out(os.path.join(DATA, "recipe", name + ".json"), data={
        "type": "minecraft:crafting_shaped", "category": "equipment", "pattern": pattern,
        "key": {k: ing(v) for k, v in key.items()}, "result": {"id": result, "count": count}})


M = "minecraft:"
H = MOD + ":"
shapeless("keeper_sigil", [M + "ender_eye", M + "rotten_flesh", M + "bone", M + "gold_ingot"], H + "keeper_sigil")
shapeless("ritual_eye", [M + "ender_eye", H + "pale_fragment", H + "pale_fragment", M + "obsidian"], H + "ritual_eye")
shapeless("ritual_pearl", [M + "ender_pearl", H + "pale_fragment"], H + "ritual_pearl")
shapeless("eden_fruit", [M + "golden_apple"] * 9, H + "eden_fruit")
shapeless("truth_lens", [M + "spyglass", M + "ender_eye", H + "pale_fragment"], H + "truth_lens")
shapeless("lightning_blade", [M + "diamond_sword", M + "lightning_rod", H + "pale_fragment", H + "pale_fragment"], H + "lightning_blade")
shapeless("pale_bread", [M + "bread", H + "pale_fragment"], H + "pale_bread")
shapeless("moon_apple", [M + "apple", M + "amethyst_shard", M + "amethyst_shard"], H + "moon_apple")
shapeless("rune_cookie", [M + "cookie", H + "pale_fragment", M + "lapis_lazuli"], H + "rune_cookie", 2)
shaped("plague_blade", ["Z", "N", "S"], {"Z": M + "slime_ball", "N": M + "netherite_ingot", "S": M + "stick"}, H + "plague_blade")
shaped("meteor_blade", ["N", "T", "S"], {"N": M + "netherite_ingot", "T": M + "nether_star", "S": M + "stick"}, H + "meteor_blade")

# ------------------------------------------------------------------ lingue: chiave -> (italiano, inglese)
L = {}
def t(key, it, en):
    L[key] = (it, en)

t("itemGroup.horroruniverse", "Horror Universe", "Horror Universe")
for k, it, en in [
    ("pale_fragment", "Frammento Pallido", "Pale Fragment"), ("keeper_sigil", "Sigillo del Custode", "Keeper's Sigil"),
    ("ritual_eye", "Occhio del Rituale", "Ritual Eye"), ("ritual_pearl", "Perla del Rituale", "Ritual Pearl"),
    ("electric_scepter", "Scettro Elettrico", "Electric Scepter"), ("truth_lens", "Lente della Verità", "Lens of Truth"),
    ("eden_fruit", "Frutto dell'Eden", "Fruit of Eden"), ("plague_blade", "Lama della Piaga", "Plague Blade"),
    ("meteor_blade", "Spada Meteorica", "Meteor Blade"), ("lightning_blade", "Lama del Fulmine", "Lightning Blade"),
    ("pale_bread", "Pane Pallido", "Pale Bread"), ("moon_apple", "Mela Lunare", "Moon Apple"),
    ("rune_cookie", "Biscotto Runico", "Rune Cookie")]:
    t("item.horroruniverse." + k, it, en)
for k, it, en in [
    ("white_eyed_keeper", "Custode dagli Occhi Bianchi", "White-Eyed Keeper"), ("keeper_minion", "Servitore del Custode", "Keeper's Minion"),
    ("white_eyed_zombie", "Zombie dagli Occhi Bianchi", "White-Eyed Zombie"), ("apparition", "Apparizione", "Apparition"),
    ("ritual_pearl", "Perla del Rituale", "Ritual Pearl")]:
    t("entity.horroruniverse." + k, it, en)
t("effect.horroruniverse.shock", "Scossa", "Shock")
t("effect.horroruniverse.eden_ward", "Protezione dell'Eden", "Eden's Ward")
for k, it, en in [("keeper", "Custode", "Keeper"), ("corrupted", "Corrotto", "Corrupted"), ("entity404", "Entity 404", "Entity 404"),
                  ("mage", "Uomo Magico", "Magic Man"), ("steve", "Steve", "Steve"), ("observer", "Osservatore", "Observer")]:
    t("horroruniverse.name." + k, it, en)
for n, it, en in [(1, "Il Custode - Il Guardiano", "The Keeper - The Guardian"),
                  (2, "Il Custode - La Prova del Contatto", "The Keeper - The Trial of Touch"),
                  (3, "Il Custode - Lo Scettro Elettrico", "The Keeper - The Electric Scepter"),
                  (4, "Il Custode Supremo", "The Supreme Keeper"),
                  (5, "Il Custode - Il Rituale Proibito", "The Keeper - The Forbidden Ritual")]:
    t("horroruniverse.boss.keeper.%d" % n, it, en)
LINES = [
    ("keeper.l1.intro", "Vediamo se sai affrontare ciò che arriva dall'oscurità.", "Let's see if you can face what comes from the dark."),
    ("keeper.l1.wave", "Ancora. Non è finita.", "Again. It is not over."),
    ("keeper.l1.defeat", "Hai superato la prima prova. Era solo un decimo di ciò che sono.", "You passed the first trial. It was a tenth of what I am."),
    ("keeper.l2.intro", "Non servono armi. Toccami. Tre volte.", "No weapons needed. Touch me. Three times."),
    ("keeper.l2.touch", "Contatto %s/%s", "Touch %s/%s"),
    ("keeper.l2.defeat", "Hai le mani ferme. Continua.", "Steady hands. Keep going."),
    ("keeper.l3.intro", "Questo scettro ricorda i fulmini di quando il mondo era giovane.", "This scepter remembers the lightning of a young world."),
    ("keeper.l3.phase", "Senti l'aria? Sta cambiando.", "Can you feel the air? It is changing."),
    ("keeper.l3.defeat", "C'è un rito che il mondo ha dimenticato. Non cercarlo... se non vuoi trovarlo.", "There is a rite the world forgot. Do not seek it... unless you wish to find it."),
    ("keeper.l4.intro", "Ora conosci i miei trucchi. Adesso vedrai il resto.", "Now you know my tricks. Now you will see the rest."),
    ("keeper.l4.phase", "Ancora non ti basta?", "Still not enough for you?"),
    ("keeper.l4.choice", "Sei in piedi. Io no. Decidi: risparmiami (clic destro a mani vuote) o finiscimi (colpiscimi ancora).", "You stand. I do not. Decide: spare me (right-click empty-handed) or finish me (strike me again)."),
    ("keeper.l4.defeat", "Hai deciso.", "You have decided."),
    ("keeper.l5.intro", "Hai fatto ciò che non dovevi. Ora il rito è aperto.", "You did what you should not have. The rite is open."),
    ("keeper.l5.window", "Ora! Le Perle possono raggiungermi!", "Now! The Pearls can reach me!"),
    ("keeper.l5.miss", "Troppo lento. Il rito continua.", "Too slow. The rite goes on."),
    ("keeper.l5.hit", "Perla valida %s/%s", "Valid pearl %s/%s"),
    ("keeper.l5.defeat", "Il rito è spezzato. Ricorda... non ero io il pericolo.", "The rite is broken. Remember... I was never the danger."),
    ("keeper.leave", "Il Custode se ne va. La prova non è completata.", "The Keeper leaves. The trial is not complete."),
    ("keeper.offer", "Ho lasciato qualcosa per te. Usalo solo quando sei pronto.", "I left something for you. Use it only when you are ready."),
    ("corrupted.whisper", "...c'è qualcuno? Non voglio farti del male.", "...is someone there? I don't want to hurt you."),
]
for k, it, en in LINES:
    t("horroruniverse.line." + k, it, en)
HINTS = [
    ("sigil.dead", "Il Custode non risponde più.", "The Keeper no longer answers."),
    ("sigil.done", "Hai già superato tutte le prove del Sigillo.", "You have already passed every Sigil trial."),
    ("sigil.busy", "Un Custode è già vicino.", "A Keeper is already near."),
    ("sigil.nospace", "Non c'è spazio libero intorno a te.", "There is no free space around you."),
    ("ritual.fizzle", "Il rito non risponde. Non sei ancora pronto.", "The rite does not answer. You are not ready."),
    ("ritual.dead", "Non c'è più nessuno che risponda al rito.", "No one is left to answer the rite."),
    ("lens", "Apparizioni rivelate: %s", "Apparitions revealed: %s"),
    ("keeper.choice", "Il Custode attende: clic destro a mani vuote per risparmiarlo, colpiscilo per ucciderlo.", "The Keeper waits: right-click empty-handed to spare, strike to kill."),
    ("reward.l1", "Hai ottenuto frammenti pallidi e un nuovo Sigillo. Il Custode ha molte altre forme.", "You received pale fragments and a new Sigil. The Keeper has many more forms."),
    ("reward.l2", "Un altro Sigillo. Dicono che il Custode abbia preso uno Scettro...", "Another Sigil. They say the Keeper took a Scepter..."),
    ("reward.l3", "Hai ottenuto lo Scettro Elettrico. Nove mele d'oro possono dare un Frutto dell'Eden.", "You received the Electric Scepter. Nine golden apples can make a Fruit of Eden."),
    ("reward.l4.kill", "Il Custode è morto per sempre. Non risponderà più.", "The Keeper is dead for good. He will not answer again."),
    ("reward.l4.spare", "Il Custode ti ha lasciato un Occhio del Rituale. Usalo su un Enderman solo se hai il coraggio.", "The Keeper left you a Ritual Eye. Use it on an Enderman only if you dare."),
    ("reward.l5", "Il rito è spezzato. Il Frutto dell'Eden è tuo.", "The rite is broken. The Fruit of Eden is yours."),
    ("deflect.immune", "I colpi normali non lo scalfiscono.", "Normal blows do not harm it."),
    ("deflect.below_threshold", "L'arma è troppo debole per ferirlo.", "Your weapon is too weak to hurt it."),
    ("deflect.not_vulnerable", "Non è vulnerabile in questo momento.", "It is not vulnerable right now."),
    ("deflect.wrong_window", "La perla non ha effetto: aspetta la finestra giusta.", "The pearl has no effect: wait for the right window."),
]
for k, it, en in HINTS:
    t("horroruniverse.hint." + k, it, en)
for k, it, en in [("watching", "Ti sto guardando.", "I am watching you."), ("behind", "Dietro di te.", "Behind you."),
                  ("dead", "Ti ho visto cadere.", "I saw you fall."), ("returned", "Sei tornato.", "You came back.")]:
    t("horroruniverse.sub." + k, it, en)

out(os.path.join(ASSETS, "lang", "it_it.json"), data={k: v[0] for k, v in L.items()})
out(os.path.join(ASSETS, "lang", "en_us.json"), data={k: v[1] for k, v in L.items()})
out(os.path.join(ROOT, "pack.mcmeta"), data={"pack": {"description": "Horror Universe", "pack_format": 34}})
print("ok: %d skin, %d icone, %d chiavi lingua" % (len(SKINS), len(ICONS), len(L)))
