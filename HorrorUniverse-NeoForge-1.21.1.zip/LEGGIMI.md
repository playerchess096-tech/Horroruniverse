# Horror Universe — Modulo 1 (NeoForge, Minecraft 1.21.1)

Mod horror con sei entità autonome. **Questo è il modulo 1**: fondamenta + il **Custode dagli Occhi Bianchi (livelli 1-5)**
+ apparizioni ed eventi horror per tutte e sei le entità + tabella completa delle regole armi/vulnerabilità.
Corrotto, Entity 404, Uomo Magico, Steve e Osservatore (boss fight) arrivano nei moduli successivi.

> **Stato della verifica:** il codice NON è stato compilato né provato in gioco (nel mio ambiente non c'è Minecraft/NeoForge
> e niente rete). Ho solo controllato che i file Java siano sintatticamente validi. La prima compilazione su GitHub Actions
> potrebbe segnalare qualche errore da correggere: mandami il log e lo sistemo.

## Ambiente
- Minecraft Java **1.21.1**, NeoForge **21.1.220**, Java **21**, ModDevGradle 2.0.141.
- Nessun `gradlew` incluso (non posso generare il wrapper): il workflow usa Gradle 9.2.1 installato dall'action.

## Compilare con GitHub Actions
1. Metti **tutto il contenuto dello zip** nella radice del repository (cartella `.github/` inclusa).
2. Fai push: parte il workflow `Build` (`.github/workflows/build.yml`).
3. Scarica il jar dall'artifact `HorrorUniverse-jar` (o da `build/libs/`) e mettilo in `mods/` con NeoForge 21.1.x.

Se usi il tuo `main.yml` (scompatta lo zip nella radice ed esegue `gradle build`): serve Java 21 e Gradle 8.8+.

## Cosa c'è dentro
- **Custode**: L1 Guardiano (3 ondate di zombie), L2 Prova del Contatto (3 contatti reali = clic destro, zombie dagli occhi bianchi
  che ricompare max 4 volte), L3 Scettro Elettrico (fulmini telegrafati, archi, zone cariche, 3 tipi di servitori, 3 fasi),
  L4 Custode Supremo (soglia attacco > 7, scelta finale: risparmia/uccidi, salvata nel mondo), L5 Rituale Proibito
  (finestre di vulnerabilità + 10 Perle del Rituale valide, Enderman, cloni, lancio in aria, Occhi di Ender temporanei).
- **Apparizioni** per tutte e sei le entità (spariscono se guardate/avvicinate; Steve lascia un regalo).
- **17 eventi horror** con probabilità, cooldown, profili (leggero/standard/intenso) e interruttori per jumpscare/effetti invasivi.
  Reagiscono a: morte, sonno, diamanti, tempo in miniera, lunga assenza, uso della Lente della Verità.
- **Regole armi** (`BossRules`): tutti i numeri della Parte 9 in una tabella, con l'attacco calcolato dall'arma (diamante = 7, netherite = 8).
- **Oggetti** (13): Frammento Pallido, Sigillo del Custode, Occhio del Rituale, Perla del Rituale, Scettro Elettrico, Frutto dell'Eden,
  Lama della Piaga (arma L3 di Entity 404), Spada Meteorica (arma L6), + extra: Lama del Fulmine, Lente della Verità, Pane Pallido,
  Mela Lunare, Biscotto Runico.

## Come si gioca il Custode
- Primo Sigillo: craftabile (occhio di Ender + carne marcia + osso + lingotto d'oro) oppure lasciato dal Custode dopo averti osservato.
- Usa il **Sigillo** → parte la prova successiva (L1→L4). Ogni vittoria dà ricompense e il Sigillo successivo.
- **Livello 5**: servono il livello 3 completato e un **Occhio del Rituale** usato con clic destro su un **Enderman**
  (ricetta: occhio di Ender + 2 frammenti pallidi + ossidiana; risparmiare il Custode al L4 ne regala uno).
- **Frutto dell'Eden** = 9 mele d'oro: 5 min di Protezione dell'Eden, che blocca SOLO gli effetti negativi della mod
  (Scossa, Oscurità, Nausea, Lentezza, Debolezza, Cecità). Non blocca danni, fulmini o colpi.

## Comandi (operatori, tranne dove indicato)
`/horror keeper <1-5>` · `/horror apparition <keeper|corrupted|entity404|mage|steve|observer>` · `/horror event <id>` ·
`/horror rules` · `/horror reset` · `/horror progress` (tutti) · `/horror options jumpscares|invasive <true|false>` (tutti)

## Checklist di test (da fare in gioco)
1. `/horror keeper 1` → barra della salute, 3 ondate; un colpo con Lama della Piaga uccide in 1 colpo.
2. `/horror keeper 2` → le spade vengono respinte; 3 clic destri entro 3.8 blocchi = vittoria; lo zombie ricompare max 4 volte.
3. `/horror keeper 4` con spada di diamante → "L'arma è troppo debole"; con netherite → danni; ultimo colpo → scelta finale.
4. `/horror keeper 5` → finestre con bagliore: tira Perle del Rituale solo lì (10 valide = vittoria).
5. `/horror event observer_footsteps`, `keeper_lightning`, `steve_observe`... per vedere gli eventi.

## Configurazione
`config/horroruniverse-common.toml`: profilo horror, intervalli, jumpscare/effetti invasivi, moltiplicatori boss
(salute/danni/velocità/durata effetti/cooldown), numero massimo di servitori/cloni, soglie armi.

## Rigenerare texture e lingue
`python3 tools/generate_assets.py` (Pillow). Le texture sono procedurali e provvisorie: puoi sostituirle con le tue.

Altri dettagli, contraddizioni trovate nel prompt e piano dei prossimi moduli: `docs/ANALISI.md`.
