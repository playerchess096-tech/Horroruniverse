package com.horroruniverse.command;

import com.horroruniverse.core.BossRules;
import com.horroruniverse.core.EntityKind;
import com.horroruniverse.core.FormRule;
import com.horroruniverse.core.Spots;
import com.horroruniverse.data.HorrorSavedData;
import com.horroruniverse.data.PlayerProfile;
import com.horroruniverse.entity.ApparitionEntity;
import com.horroruniverse.entity.WhiteEyedKeeper;
import com.horroruniverse.event.HorrorDirector;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * /horror ... Comandi di test (operatori, livello 2) e opzioni personali (tutti i giocatori):
 *   /horror keeper <1-5>            evoca il Custode a quel livello
 *   /horror apparition <entita>     evoca un'apparizione (keeper, corrupted, entity404, mage, steve, observer)
 *   /horror event <id>              esegue un evento horror ignorando condizioni e giorni minimi
 *   /horror rules                   stampa la tabella armi/vulnerabilita'
 *   /horror progress                mostra la tua progressione
 *   /horror reset                   azzera la tua progressione (solo dati della mod)
 *   /horror options jumpscares|invasive <true|false>
 */
public final class HorrorCommands {
    private HorrorCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("horror")
                .then(Commands.literal("keeper").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("level", IntegerArgumentType.integer(1, 5))
                                .executes(ctx -> keeper(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "level")))))
                .then(Commands.literal("apparition").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("kind", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(kindIds(), b))
                                .executes(ctx -> apparition(ctx.getSource(), StringArgumentType.getString(ctx, "kind")))))
                .then(Commands.literal("event").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(HorrorDirector.eventIds(), b))
                                .executes(ctx -> event(ctx.getSource(), StringArgumentType.getString(ctx, "id")))))
                .then(Commands.literal("rules").requires(s -> s.hasPermission(2)).executes(ctx -> rules(ctx.getSource())))
                .then(Commands.literal("progress").executes(ctx -> progress(ctx.getSource())))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2)).executes(ctx -> reset(ctx.getSource())))
                .then(Commands.literal("options")
                        .then(Commands.literal("jumpscares").then(Commands.argument("enabled", BoolArgumentType.bool())
                                .executes(ctx -> option(ctx.getSource(), true, BoolArgumentType.getBool(ctx, "enabled")))))
                        .then(Commands.literal("invasive").then(Commands.argument("enabled", BoolArgumentType.bool())
                                .executes(ctx -> option(ctx.getSource(), false, BoolArgumentType.getBool(ctx, "enabled")))))));
    }

    private static List<String> kindIds() {
        List<String> ids = new ArrayList<>();
        for (EntityKind k : EntityKind.values()) ids.add(k.id);
        return ids;
    }

    private static void msg(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    private static int keeper(CommandSourceStack src, int level) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        if (WhiteEyedKeeper.activeNear(p.serverLevel(), p.position(), 128.0D)) {
            src.sendFailure(Component.literal("C'e' gia' un Custode nelle vicinanze."));
            return 0;
        }
        WhiteEyedKeeper k = WhiteEyedKeeper.summon(p, level);
        if (k == null) {
            src.sendFailure(Component.literal("Nessun punto libero vicino a te."));
            return 0;
        }
        msg(src, "Custode livello " + level + " evocato.");
        return 1;
    }

    private static int apparition(CommandSourceStack src, String id) throws CommandSyntaxException {
        EntityKind kind = EntityKind.byId(id);
        if (kind == null) {
            src.sendFailure(Component.literal("Entita' sconosciuta: " + id));
            return 0;
        }
        ServerPlayer p = src.getPlayerOrException();
        Vec3 pos = Spots.find(p.serverLevel(), p.position(), 10.0D, 16.0D, 30, 4);
        if (pos == null || ApparitionEntity.spawn(p.serverLevel(), kind, pos, ApparitionEntity.Behavior.VANISH_ON_LOOK, 20 * 60, 0.0D, false) == null) {
            src.sendFailure(Component.literal("Nessun punto libero vicino a te."));
            return 0;
        }
        msg(src, "Apparizione: " + kind.id);
        return 1;
    }

    private static int event(CommandSourceStack src, String id) throws CommandSyntaxException {
        if (!HorrorDirector.forceRun(src.getPlayerOrException(), id)) {
            src.sendFailure(Component.literal("Evento sconosciuto: " + id));
            return 0;
        }
        msg(src, "Evento eseguito: " + id);
        return 1;
    }

    private static int rules(CommandSourceStack src) {
        for (FormRule r : BossRules.all()) {
            msg(src, r.id() + " | " + r.type() + " | arma L3: " + r.hitsL3() + " colpi, arma L6: " + r.hitsL6() + " colpi"
                    + (r.minAttack() > 0 ? " | attacco " + (r.inclusive() ? ">= " : "> ") + r.minAttack() : "")
                    + (r.proposed() ? " | PROPOSTA" : "") + " | " + r.note());
        }
        return BossRules.all().size();
    }

    private static int progress(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerProfile prof = HorrorSavedData.get(p.serverLevel().getServer()).profile(p);
        for (EntityKind k : EntityKind.values()) {
            msg(src, k.id + ": livello completato " + prof.done(k) + ", relazione " + prof.relation[k.ordinal()]);
        }
        msg(src, "Scelte/flag: " + (prof.flags.isEmpty() ? "nessuna" : String.join(", ", prof.flags)));
        msg(src, "Jumpscare: " + prof.jumpscares + " | effetti invasivi: " + prof.invasive);
        return 1;
    }

    private static int reset(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerProfile prof = HorrorSavedData.get(p.serverLevel().getServer()).profile(p);
        Arrays.fill(prof.levelDone, 0);
        Arrays.fill(prof.relation, 0);
        prof.flags.clear();
        prof.cooldowns.clear();
        prof.memory.clear();
        prof.nextEventTick = 0L;
        prof.diamonds = 0;
        prof.deaths = 0;
        prof.minedTicks = 0L;
        msg(src, "Progressione della mod azzerata (mondo e inventario non toccati).");
        return 1;
    }

    private static int option(CommandSourceStack src, boolean jumpscares, boolean enabled) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerProfile prof = HorrorSavedData.get(p.serverLevel().getServer()).profile(p);
        if (jumpscares) prof.jumpscares = enabled;
        else prof.invasive = enabled;
        msg(src, (jumpscares ? "Jumpscare: " : "Effetti invasivi: ") + enabled);
        return 1;
    }
}
