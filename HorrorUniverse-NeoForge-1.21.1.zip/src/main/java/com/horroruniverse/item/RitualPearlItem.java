package com.horroruniverse.item;

import com.horroruniverse.core.SpecialWeapon;
import com.horroruniverse.core.SpecialWeaponItem;
import com.horroruniverse.entity.RitualPearlEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Perla del Rituale: l'unica perla "valida" contro il Custode livello 5 (e solo durante la finestra). */
public class RitualPearlItem extends Item implements SpecialWeaponItem {
    public RitualPearlItem(Properties properties) {
        super(properties);
    }

    @Override
    public SpecialWeapon specialWeapon() {
        return SpecialWeapon.RITUAL_PEARL;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENDER_PEARL_THROW,
                SoundSource.NEUTRAL, 0.5F, 0.4F / (level.getRandom().nextFloat() * 0.4F + 0.8F));
        player.getCooldowns().addCooldown(this, 12);
        if (!level.isClientSide) {
            RitualPearlEntity pearl = new RitualPearlEntity(level, player);
            pearl.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.6F, 1.0F);
            level.addFreshEntity(pearl);
        }
        if (!player.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
