package com.horroruniverse.item;

import com.horroruniverse.core.SpecialWeapon;
import com.horroruniverse.core.SpecialWeaponItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Spada speciale: distinta dalle armi normali tramite SpecialWeaponItem (non dal nome dell'oggetto). */
public class SpecialSwordItem extends SwordItem implements SpecialWeaponItem {
    private final SpecialWeapon kind;

    public SpecialSwordItem(Tier tier, Properties properties, SpecialWeapon kind) {
        super(tier, properties);
        this.kind = kind;
    }

    @Override
    public SpecialWeapon specialWeapon() {
        return kind;
    }
}
