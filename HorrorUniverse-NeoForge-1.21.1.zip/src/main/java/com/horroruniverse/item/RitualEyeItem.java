package com.horroruniverse.item;

import com.horroruniverse.core.EntityKind;
import com.horroruniverse.core.Fx;
import com.horroruniverse.data.HorrorSavedData;
import com.horroruniverse.data.PlayerProfile;
import com.horroruniverse.entity.WhiteEyedKeeper;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Occhio del Rituale: si usa CON UN CLIC DESTRO SU UN ENDERMAN. Se il giocatore ha superato il livello 3 del Custode
 * (e il Custode non e' stato ucciso) il rituale e' proibito e apre il livello 5.
 */
public class RitualEyeItem extends Item {
    public RitualEyeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof EnderMan)) return InteractionResult.PASS;
        if (player.level().isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
        ServerLevel sl = sp.serverLevel();
        PlayerProfile profile = HorrorSavedData.get(sl.getServer()).profile(sp);
        if (profile.flags.contains("keeper_killed")) {
            Fx.hint(sp, "ritual.dead");
            return InteractionResult.FAIL;
        }
        if (profile.done(EntityKind.KEEPER) < 3) {
            sl.sendParticles(ParticleTypes.SMOKE, target.getX(), target.getY() + 1.5D, target.getZ(), 20, 0.3D, 0.5D, 0.3D, 0.02D);
            Fx.hint(sp, "ritual.fizzle");
            return InteractionResult.FAIL;
        }
        if (WhiteEyedKeeper.activeNear(sl, sp.position(), 128.0D)) {
            Fx.hint(sp, "sigil.busy");
            return InteractionResult.FAIL;
        }
        WhiteEyedKeeper keeper = WhiteEyedKeeper.summon(sp, 5);
        if (keeper == null) {
            Fx.hint(sp, "sigil.nospace");
            return InteractionResult.FAIL;
        }
        sl.sendParticles(ParticleTypes.PORTAL, target.getX(), target.getY() + 1.5D, target.getZ(), 60, 0.4D, 0.8D, 0.4D, 0.6D);
        target.discard(); // l'Enderman viene consumato dal rituale
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        return InteractionResult.CONSUME;
    }
}
