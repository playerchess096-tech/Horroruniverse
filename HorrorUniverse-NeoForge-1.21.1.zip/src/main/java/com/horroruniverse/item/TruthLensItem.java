package com.horroruniverse.item;

import com.horroruniverse.core.EntityKind;
import com.horroruniverse.core.Fx;
import com.horroruniverse.data.HorrorSavedData;
import com.horroruniverse.data.PlayerProfile;
import com.horroruniverse.entity.ApparitionEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Lente della Verita': evidenzia le apparizioni entro 40 blocchi. Usarla di continuo rende l'Osservatore
 * piu' prudente (le sue apparizioni diventano piu' lontane e rare), come descritto nella Parte 1.2.
 */
public class TruthLensItem extends Item {
    public TruthLensItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        ServerLevel sl = sp.serverLevel();
        int found = 0;
        for (ApparitionEntity a : sl.getEntitiesOfClass(ApparitionEntity.class, sp.getBoundingBox().inflate(40.0D))) {
            a.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
            found++;
        }
        PlayerProfile profile = HorrorSavedData.get(sl.getServer()).profile(sp);
        profile.remember(EntityKind.OBSERVER, "searched", sl.getGameTime(), sp.blockPosition());
        Fx.actionBar(sp, net.minecraft.network.chat.Component.translatable("horroruniverse.hint.lens", found));
        sp.getCooldowns().addCooldown(this, 100);
        return InteractionResultHolder.consume(stack);
    }
}
