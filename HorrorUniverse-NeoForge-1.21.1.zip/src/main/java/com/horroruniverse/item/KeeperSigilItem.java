package com.horroruniverse.item;

import com.horroruniverse.core.EntityKind;
import com.horroruniverse.core.Fx;
import com.horroruniverse.data.HorrorSavedData;
import com.horroruniverse.data.PlayerProfile;
import com.horroruniverse.entity.WhiteEyedKeeper;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Sigillo del Custode: avvia la prossima prova (livelli 1-4). Il livello 5 si apre solo con il rituale. */
public class KeeperSigilItem extends Item {
    public KeeperSigilItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        ServerLevel sl = sp.serverLevel();
        PlayerProfile profile = HorrorSavedData.get(sl.getServer()).profile(sp);
        if (profile.flags.contains("keeper_killed")) {
            Fx.hint(sp, "sigil.dead");
            return InteractionResultHolder.fail(stack);
        }
        int next = profile.done(EntityKind.KEEPER) + 1;
        if (next > 4) {
            Fx.hint(sp, "sigil.done");
            return InteractionResultHolder.fail(stack);
        }
        if (WhiteEyedKeeper.activeNear(sl, sp.position(), 128.0D)) {
            Fx.hint(sp, "sigil.busy");
            return InteractionResultHolder.fail(stack);
        }
        WhiteEyedKeeper keeper = WhiteEyedKeeper.summon(sp, next);
        if (keeper == null) {
            Fx.hint(sp, "sigil.nospace");
            return InteractionResultHolder.fail(stack);
        }
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.consume(stack);
    }
}
