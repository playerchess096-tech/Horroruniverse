package com.horroruniverse.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Frutto dell'Eden: dona Protezione dell'Eden (5 minuti) e ha un cooldown, quindi non rende invincibili. */
public class EdenFruitItem extends Item {
    public EdenFruitItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (entity instanceof Player player) {
            player.getCooldowns().addCooldown(this, 600);
        }
        return result;
    }
}
