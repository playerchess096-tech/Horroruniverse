package com.horroruniverse.item;

import com.horroruniverse.core.HorrorEffects;
import com.horroruniverse.registry.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Arma extra: spada con attacco 7 che applica Scossa al bersaglio. Non e' un'arma speciale per le regole dei boss. */
public class LightningBladeItem extends SwordItem {
    public LightningBladeItem(Tier tier, Properties properties) {
        super(tier, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (!target.level().isClientSide && target.level() instanceof ServerLevel sl) {
            HorrorEffects.apply(target, ModEffects.SHOCK, 100, 0);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + target.getBbHeight() * 0.5D,
                    target.getZ(), 10, 0.3D, 0.4D, 0.3D, 0.1D);
        }
        return result;
    }
}
