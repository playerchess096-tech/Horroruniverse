package com.horroruniverse.item;

import com.horroruniverse.core.HorrorEffects;
import com.horroruniverse.registry.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

/** Scettro Elettrico: colpisce con un fulmine (solo visivo + danno controllato) il punto o la creatura mirata. */
public class ElectricScepterItem extends Item {
    private static final double RANGE = 28.0D;

    public ElectricScepterItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        if (level.isClientSide || !(level instanceof ServerLevel sl)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(RANGE));
        BlockHitResult hit = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 target = hit.getLocation();
        double best = target.distanceToSqr(eye);
        AABB box = new AABB(eye, end).inflate(1.5D);
        for (Entity e : sl.getEntities(player, box, x -> x instanceof LivingEntity && !x.isSpectator())) {
            Optional<Vec3> o = e.getBoundingBox().inflate(0.4D).clip(eye, end);
            if (o.isPresent()) {
                double d = eye.distanceToSqr(o.get());
                if (d < best) {
                    best = d;
                    target = o.get();
                }
            }
        }
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
        if (bolt != null) {
            bolt.moveTo(target.x, target.y, target.z);
            bolt.setVisualOnly(true);
            sl.addFreshEntity(bolt);
        }
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.x, target.y + 0.5D, target.z, 25, 1.0D, 0.5D, 1.0D, 0.2D);
        for (LivingEntity victim : sl.getEntitiesOfClass(LivingEntity.class, new AABB(target, target).inflate(2.5D))) {
            if (victim == player) continue;
            victim.hurt(sl.damageSources().lightningBolt(), 9.0F);
            HorrorEffects.apply(victim, ModEffects.SHOCK, 120, 0);
        }
        stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
        player.getCooldowns().addCooldown(this, 80);
        return InteractionResultHolder.consume(stack);
    }
}
