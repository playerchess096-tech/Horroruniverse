package com.horroruniverse.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Configurazione comune (config/horroruniverse-common.toml). Le opzioni piu' pericolose sono disattivabili. */
public final class HorrorConfig {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    // --- atmosfera ---
    public static final ModConfigSpec.EnumValue<HorrorProfile> PROFILE = B
            .comment("Profilo horror: LIGHT (eventi rari), STANDARD, INTENSE (eventi frequenti). Non cambia la potenza dei boss.")
            .defineEnum("horrorProfile", HorrorProfile.STANDARD);
    public static final ModConfigSpec.BooleanValue AMBIENT_EVENTS = B
            .comment("Eventi horror ambientali (passi, apparizioni, fulmini lontani...).")
            .define("ambientEventsEnabled", true);
    public static final ModConfigSpec.IntValue MIN_EVENT_SECONDS = B
            .comment("Secondi minimi fra due eventi ambientali per giocatore (profilo STANDARD).")
            .defineInRange("minEventIntervalSeconds", 120, 10, 7200);
    public static final ModConfigSpec.IntValue MAX_EVENT_SECONDS = B
            .comment("Secondi massimi fra due eventi ambientali per giocatore (profilo STANDARD).")
            .defineInRange("maxEventIntervalSeconds", 360, 20, 14400);
    public static final ModConfigSpec.BooleanValue JUMPSCARES = B
            .comment("Jumpscare (titoli + suoni forti). Ogni giocatore puo' anche disattivarli con /horror options jumpscares false.")
            .define("jumpscaresEnabled", true);
    public static final ModConfigSpec.BooleanValue INVASIVE_EFFECTS = B
            .comment("Effetti invasivi (oscurita', nausea, lancio in aria). Ogni giocatore puo' disattivarli con /horror options invasive false.")
            .define("invasiveEffectsEnabled", true);
    public static final ModConfigSpec.IntValue APPARITION_SECONDS = B
            .comment("Durata massima delle apparizioni fuori dalle boss fight (secondi).")
            .defineInRange("apparitionMaxSeconds", 90, 5, 600);

    // --- boss ---
    public static final ModConfigSpec.DoubleValue BOSS_HEALTH = B
            .comment("Moltiplicatore salute dei boss.")
            .defineInRange("bossHealthMultiplier", 1.0D, 0.1D, 10.0D);
    public static final ModConfigSpec.DoubleValue BOSS_DAMAGE = B
            .comment("Moltiplicatore danni dei boss.")
            .defineInRange("bossDamageMultiplier", 1.0D, 0.1D, 10.0D);
    public static final ModConfigSpec.DoubleValue BOSS_SPEED = B
            .comment("Moltiplicatore velocita' dei boss.")
            .defineInRange("bossSpeedMultiplier", 1.0D, 0.5D, 2.0D);
    public static final ModConfigSpec.DoubleValue EFFECT_DURATION = B
            .comment("Moltiplicatore durata degli effetti negativi inflitti dalla mod.")
            .defineInRange("effectDurationMultiplier", 1.0D, 0.1D, 5.0D);
    public static final ModConfigSpec.DoubleValue COOLDOWN = B
            .comment("Moltiplicatore dei cooldown delle abilita' (piu' alto = abilita' piu' rare).")
            .defineInRange("abilityCooldownMultiplier", 1.0D, 0.25D, 4.0D);
    public static final ModConfigSpec.IntValue MAX_MINIONS = B
            .comment("Numero massimo di mostri evocati vivi contemporaneamente da un boss.")
            .defineInRange("maxMinionsPerFight", 6, 1, 20);
    public static final ModConfigSpec.IntValue MAX_CLONES = B
            .comment("Numero massimo di cloni/esche contemporanei (Custode livello 5).")
            .defineInRange("maxClonesPerFight", 2, 0, 8);
    public static final ModConfigSpec.IntValue ABANDON_SECONDS = B
            .comment("Se nessun giocatore e' vicino per questo tempo il boss se ne va (nessun progresso).")
            .defineInRange("abandonSeconds", 30, 5, 600);

    // --- armi / vulnerabilita' ---
    public static final ModConfigSpec.BooleanValue WEAPON_THRESHOLDS = B
            .comment("Se false, le vulnerabilita' per soglia di attacco si comportano come vulnerabilita' normale.")
            .define("weaponThresholdsEnabled", true);

    public static final ModConfigSpec SPEC = B.build();

    private HorrorConfig() {}
}
