package com.horroruniverse.config;

/** Profili di orrore (Parte 13.1): cambiano la frequenza degli eventi, NON la potenza dei boss. */
public enum HorrorProfile {
    LIGHT(2.0D),
    STANDARD(1.0D),
    INTENSE(0.5D);

    /** Moltiplicatore applicato all'intervallo fra due eventi (piu' alto = eventi piu' rari). */
    public final double intervalFactor;

    HorrorProfile(double intervalFactor) {
        this.intervalFactor = intervalFactor;
    }
}
