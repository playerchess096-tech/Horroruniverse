package com.horroruniverse.event;

import com.horroruniverse.HorrorUniverse;
import com.horroruniverse.config.HorrorConfig;
import com.horroruniverse.core.EntityKind;
import com.horroruniverse.core.Fx;
import com.horroruniverse.core.HorrorEffects;
import com.horroruniverse.core.Spots;
import com.horroruniverse.data.HorrorSavedData;
import com.horroruniverse.data.PlayerProfile;
import com.horroruniverse.entity.ApparitionEntity;
import com.horroruniverse.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Sistema condiviso di eventi horror (Parte 13). Ogni evento appartiene a UN'entita' e ha peso, cooldown,
 * condizioni e flag jumpscare/invasivo. Gli eventi sono scelti con probabilita' e intervalli (mai a ogni tick)
 * e reagiscono solo a cio' che il sistema registra: morte, sonno, diamanti, tempo in miniera, lunga assenza.
 */
public final class HorrorDirector {
    public record Ctx(ServerPlayer player, ServerLevel level, PlayerProfile profile, long now, RandomSource rnd) {}

    public record Event(String id, EntityKind owner, int weight, int cooldownTicks, boolean jumpscare, boolean invasive,
                        Predicate<Ctx> condition, Consumer<Ctx> action) {}

    private static final Map<String, Event> EVENTS = new LinkedHashMap<>();
    private static final Map<UUID, String> QUEUED = new HashMap<>();
    private static final DustParticleOptions GREEN_DUST = new DustParticleOptions(new Vector3f(0.2F, 1.0F, 0.25F), 1.2F);

    private HorrorDirector() {}

    private static void reg(String id, EntityKind owner, int weight, int cooldownSeconds, boolean jumpscare,
                            boolean invasive, Predicate<Ctx> condition, Consumer<Ctx> action) {
        EVENTS.put(id, new Event(id, owner, weight, cooldownSeconds * 20, jumpscare, invasive, condition, action));
    }

    static {
        // ---- L'Osservatore: silenzio, passi, apparizioni ----
        reg("observer_footsteps", EntityKind.OBSERVER, 10, 240, false, false,
                c -> c.player().onGround() && !c.player().isInWater(), HorrorDirector::footsteps);
        reg("observer_creeper_hiss", EntityKind.OBSERVER, 6, 400, false, false, c -> true,
                c -> Fx.sound(c.player(), SoundEvents.CREEPER_PRIMED, Spots.behind(c.player(), 6.0D), 0.9F, 1.0F));
        reg("observer_heartbeat", EntityKind.OBSERVER, 6, 360, false, false, c -> true, HorrorDirector::heartbeat);
        reg("observer_distant_figure", EntityKind.OBSERVER, 8, 420, false, false,
                c -> c.profile().countRecent(EntityKind.OBSERVER, "searched", c.now() - 24000L) < 3 || c.rnd().nextFloat() < 0.35F,
                HorrorDirector::distantFigure);
        reg("observer_fake_join", EntityKind.OBSERVER, 4, 900, false, false, c -> true, HorrorDirector::fakeJoin);
        reg("observer_darkness", EntityKind.OBSERVER, 3, 600, false, true, c -> true, c -> {
            HorrorEffects.apply(c.player(), MobEffects.DARKNESS, 140, 0);
            heartbeat(c);
        });
        reg("observer_door", EntityKind.OBSERVER, 3, 500, false, false, c -> true, HorrorDirector::doorSound);
        reg("observer_subtitle", EntityKind.OBSERVER, 4, 900, true, false, c -> true, c -> {
            Fx.creepyTitle(c.player(), c.rnd().nextBoolean() ? "watching" : "behind");
            Fx.sound(c.player(), SoundEvents.WARDEN_HEARTBEAT, c.player().position(), 1.0F, 0.8F);
        });
        reg("observer_after_death", EntityKind.OBSERVER, 0, 60, true, false, c -> true, c -> {
            Fx.creepyTitle(c.player(), "dead");
            footsteps(c);
        });

        // ---- Il Custode: fulmini, rituali, occhi bianchi ----
        reg("keeper_lightning", EntityKind.KEEPER, 6, 480, false, false,
                c -> !c.profile().flags.contains("keeper_killed") && c.level().canSeeSky(c.player().blockPosition()),
                HorrorDirector::keeperLightning);
        reg("keeper_white_eyes", EntityKind.KEEPER, 6, 600, false, false,
                c -> !c.profile().flags.contains("keeper_killed"), c -> {
                    Vec3 pos = Spots.find(c.level(), c.player().position(), 24.0D, 36.0D, 25, 5);
                    if (pos == null) return;
                    ApparitionEntity.spawn(c.level(), EntityKind.KEEPER, pos, ApparitionEntity.Behavior.VANISH_ON_APPROACH,
                            HorrorConfig.APPARITION_SECONDS.get() * 20, 14.0D, false);
                    c.profile().remember(EntityKind.KEEPER, "apparition", c.now(), BlockPos.containing(pos));
                });
        reg("keeper_symbol", EntityKind.KEEPER, 5, 700, false, false,
                c -> !c.profile().flags.contains("keeper_killed"), HorrorDirector::keeperSymbol);
        reg("keeper_offer_sigil", EntityKind.KEEPER, 25, 1800, false, false, HorrorDirector::canOfferSigil, HorrorDirector::offerSigil);

        // ---- Corrotto, Entity 404, Uomo Magico, Steve: solo presenza, le boss fight arrivano nei prossimi moduli ----
        reg("corrupted_whisper", EntityKind.CORRUPTED, 4, 900, false, false, c -> true, c -> {
            Vec3 pos = Spots.find(c.level(), c.player().position(), 20.0D, 30.0D, 25, 5);
            if (pos == null) return;
            ApparitionEntity.spawn(c.level(), EntityKind.CORRUPTED, pos, ApparitionEntity.Behavior.VANISH_ON_LOOK,
                    HorrorConfig.APPARITION_SECONDS.get() * 20, 0.0D, false);
            Fx.say(c.player(), EntityKind.CORRUPTED, "corrupted.whisper");
        });
        reg("entity404_numbers", EntityKind.ENTITY_404, 3, 1200, false, false, c -> true, HorrorDirector::numbers404);
        reg("mage_runes", EntityKind.MAGE, 4, 900, false, false, c -> true, HorrorDirector::mageRunes);
        reg("steve_observe", EntityKind.STEVE, 4, 900, false, false, c -> true, c -> {
            Vec3 pos = Spots.find(c.level(), c.player().position(), 30.0D, 45.0D, 25, 6);
            if (pos == null) return;
            ApparitionEntity.spawn(c.level(), EntityKind.STEVE, pos, ApparitionEntity.Behavior.GIFT_ON_APPROACH,
                    HorrorConfig.APPARITION_SECONDS.get() * 20, 0.0D, false);
            c.profile().remember(EntityKind.STEVE, "apparition", c.now(), BlockPos.containing(pos));
        });
    }

    public static Collection<String> eventIds() {
        return EVENTS.keySet();
    }

    public static void reset() {
        QUEUED.clear();
        HorrorScheduler.clear();
    }

    // ------------------------------------------------------------------ ciclo
    public static void onServerTick(MinecraftServer server) {
        HorrorScheduler.tick(server);
        if (server.getTickCount() % 40 != 0 || !HorrorConfig.AMBIENT_EVENTS.get()) return;
        HorrorSavedData data = HorrorSavedData.get(server);
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            try {
                tickPlayer(data, p);
            } catch (RuntimeException ex) {
                HorrorUniverse.LOGGER.warn("Errore in un evento horror", ex);
            }
        }
    }

    private static void tickPlayer(HorrorSavedData data, ServerPlayer p) {
        if (p.isSpectator() || !p.isAlive()) return;
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        PlayerProfile prof = data.profile(p);
        prof.playedTicks += 40;
        if (p.getY() < 40.0D && !level.canSeeSky(p.blockPosition())) prof.minedTicks += 40;
        if (prof.minedTicks > 20L * 60L * 12L) {
            prof.minedTicks = 0;
            if (level.random.nextFloat() < 0.5F) QUEUED.put(p.getUUID(), "observer_footsteps");
        }
        if (prof.nextEventTick == 0L) {
            prof.nextEventTick = now + interval(level.random);
            return;
        }
        if (now < prof.nextEventTick) return;
        Ctx c = new Ctx(p, level, prof, now, level.random);
        Event chosen = null;
        String queued = QUEUED.remove(p.getUUID());
        if (queued != null) {
            Event q = EVENTS.get(queued);
            if (q != null && prof.cooledDown(q.id(), now) && togglesAllow(q, c)) chosen = q;
        }
        if (chosen == null) chosen = pick(c);
        if (chosen != null) {
            chosen.action().accept(c);
            prof.setCooldown(chosen.id(), now + chosen.cooldownTicks());
        }
        prof.nextEventTick = now + interval(level.random);
    }

    private static long interval(RandomSource rnd) {
        int min = HorrorConfig.MIN_EVENT_SECONDS.get();
        int max = Math.max(min + 1, HorrorConfig.MAX_EVENT_SECONDS.get());
        double seconds = (min + rnd.nextInt(max - min + 1)) * HorrorConfig.PROFILE.get().intervalFactor;
        return Math.max(200L, Math.round(seconds * 20.0D));
    }

    private static boolean togglesAllow(Event e, Ctx c) {
        if (e.jumpscare() && !(HorrorConfig.JUMPSCARES.get() && c.profile().jumpscares)) return false;
        return !e.invasive() || (HorrorConfig.INVASIVE_EFFECTS.get() && c.profile().invasive);
    }

    private static Event pick(Ctx c) {
        List<Event> eligible = new ArrayList<>();
        int total = 0;
        for (Event e : EVENTS.values()) {
            if (e.weight() <= 0) continue;
            if (c.profile().playedTicks < (long) e.owner().minDay * 24000L) continue;
            if (!c.profile().cooledDown(e.id(), c.now()) || !togglesAllow(e, c)) continue;
            if (!e.condition().test(c)) continue;
            eligible.add(e);
            total += e.weight();
        }
        if (total <= 0) return null;
        int roll = c.rnd().nextInt(total);
        for (Event e : eligible) {
            roll -= e.weight();
            if (roll < 0) return e;
        }
        return null;
    }

    /** Per /horror event: esegue un evento ignorando condizioni e giorni minimi. */
    public static boolean forceRun(ServerPlayer p, String id) {
        Event e = EVENTS.get(id);
        if (e == null) return false;
        ServerLevel level = p.serverLevel();
        PlayerProfile prof = HorrorSavedData.get(level.getServer()).profile(p);
        e.action().accept(new Ctx(p, level, prof, level.getGameTime(), level.random));
        return true;
    }

    // ------------------------------------------------------------------ hook di gioco
    public static void onLogin(Player player) {
        if (!(player instanceof ServerPlayer sp)) return;
        MinecraftServer server = sp.serverLevel().getServer();
        PlayerProfile prof = HorrorSavedData.get(server).profile(sp);
        long now = sp.serverLevel().getGameTime();
        // ritorno dopo una lunga assenza (3 giorni di gioco): l'Osservatore "se ne accorge"
        if (prof.lastSeenTick > 0L && now - prof.lastSeenTick >= 72000L && HorrorConfig.AMBIENT_EVENTS.get()
                && HorrorConfig.JUMPSCARES.get() && prof.jumpscares) {
            UUID id = sp.getUUID();
            HorrorScheduler.schedule(server, 200, () -> {
                ServerPlayer p = server.getPlayerList().getPlayer(id);
                if (p != null) Fx.creepyTitle(p, "returned");
            });
        }
        prof.lastSeenTick = now;
    }

    public static void onLogout(Player player) {
        if (!(player instanceof ServerPlayer sp)) return;
        HorrorSavedData.get(sp.serverLevel().getServer()).profile(sp).lastSeenTick = sp.serverLevel().getGameTime();
    }

    public static void onDeath(LivingEntity entity) {
        if (!(entity instanceof ServerPlayer sp)) return;
        ServerLevel level = sp.serverLevel();
        PlayerProfile prof = HorrorSavedData.get(level.getServer()).profile(sp);
        prof.deaths++;
        prof.remember(EntityKind.OBSERVER, "death", level.getGameTime(), sp.blockPosition());
        QUEUED.put(sp.getUUID(), "observer_after_death");
        prof.nextEventTick = level.getGameTime() + 4800L + level.random.nextInt(3600);
    }

    public static void onWake(LivingEntity entity) {
        if (!(entity instanceof ServerPlayer sp)) return;
        ServerLevel level = sp.serverLevel();
        if (level.random.nextFloat() < 0.4F) {
            PlayerProfile prof = HorrorSavedData.get(level.getServer()).profile(sp);
            prof.remember(EntityKind.OBSERVER, "sleep", level.getGameTime(), sp.blockPosition());
            QUEUED.put(sp.getUUID(), "observer_distant_figure");
            prof.nextEventTick = level.getGameTime() + 600L + level.random.nextInt(600);
        }
    }

    public static void onBreak(Player player, BlockState state) {
        if (!(player instanceof ServerPlayer sp) || !state.is(Tags.Blocks.ORES_DIAMOND)) return;
        ServerLevel level = sp.serverLevel();
        PlayerProfile prof = HorrorSavedData.get(level.getServer()).profile(sp);
        prof.diamonds++;
        prof.remember(EntityKind.OBSERVER, "diamond", level.getGameTime(), sp.blockPosition());
        if (prof.diamonds % 4 == 0 && level.random.nextFloat() < 0.6F) {
            QUEUED.put(sp.getUUID(), "observer_heartbeat");
            prof.nextEventTick = level.getGameTime() + 400L + level.random.nextInt(400);
        }
    }

    // ------------------------------------------------------------------ eventi
    private static void later(Ctx c, int ticks, Consumer<ServerPlayer> task) {
        MinecraftServer server = c.level().getServer();
        UUID id = c.player().getUUID();
        HorrorScheduler.schedule(server, ticks, () -> {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null && p.isAlive()) task.accept(p);
        });
    }

    private static void footsteps(Ctx c) {
        int n = 4 + c.rnd().nextInt(3);
        for (int i = 0; i < n; i++) {
            final double dist = 7.0D - i * 0.8D;
            later(c, 20 + i * 11, p -> {
                SoundEvent step = p.level().getBlockState(p.blockPosition().below()).getSoundType().getStepSound();
                Fx.sound(p, step, Spots.behind(p, dist), 0.9F, 0.85F);
            });
        }
        c.profile().remember(EntityKind.OBSERVER, "footsteps", c.now(), c.player().blockPosition());
    }

    private static void heartbeat(Ctx c) {
        for (int i = 0; i < 4; i++) {
            final float volume = 1.0F - i * 0.2F;
            later(c, i * 20, p -> Fx.sound(p, SoundEvents.WARDEN_HEARTBEAT, p.position(), volume, 1.0F));
        }
    }

    private static void distantFigure(Ctx c) {
        boolean cautious = c.profile().countRecent(EntityKind.OBSERVER, "searched", c.now() - 24000L) >= 3;
        Vec3 pos = Spots.find(c.level(), c.player().position(), cautious ? 45.0D : 26.0D, cautious ? 60.0D : 40.0D, 25, 6);
        if (pos == null) return;
        ApparitionEntity.spawn(c.level(), EntityKind.OBSERVER, pos, ApparitionEntity.Behavior.VANISH_ON_LOOK,
                HorrorConfig.APPARITION_SECONDS.get() * 20, 0.0D, false);
        c.profile().remember(EntityKind.OBSERVER, "apparition", c.now(), BlockPos.containing(pos));
    }

    /** Messaggio finto di ingresso: solo testo, non crea nessun giocatore reale. */
    private static void fakeJoin(Ctx c) {
        c.player().sendSystemMessage(Component.translatable("multiplayer.player.joined", Component.literal("Osservatore"))
                .withStyle(ChatFormatting.YELLOW));
        later(c, 100 + c.rnd().nextInt(100), p -> p.sendSystemMessage(
                Component.translatable("multiplayer.player.left", Component.literal("Osservatore")).withStyle(ChatFormatting.YELLOW)));
    }

    private static void doorSound(Ctx c) {
        Vec3 pos = Spots.behind(c.player(), 5.0D);
        Fx.sound(c.player(), SoundEvents.WOODEN_DOOR_OPEN, pos, 1.0F, 0.9F);
        later(c, 40, p -> Fx.sound(p, SoundEvents.WOODEN_DOOR_CLOSE, pos, 1.0F, 0.9F));
    }

    private static void keeperLightning(Ctx c) {
        Vec3 pos = Spots.find(c.level(), c.player().position(), 40.0D, 70.0D, 15, 30);
        if (pos == null) return;
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(c.level());
        if (bolt == null) return;
        bolt.moveTo(pos.x, pos.y, pos.z);
        bolt.setVisualOnly(true);
        c.level().addFreshEntity(bolt);
        Fx.sound(c.player(), SoundEvents.LIGHTNING_BOLT_THUNDER, pos, 2.0F, 1.0F);
        c.profile().remember(EntityKind.KEEPER, "lightning", c.now(), BlockPos.containing(pos));
    }

    private static void ring(Ctx c, Vec3 center, ParticleOptions particle, double radius, int points) {
        for (int burst = 0; burst < 4; burst++) {
            later(c, burst * 12, p -> {
                for (int i = 0; i < points; i++) {
                    double a = i * Math.PI * 2.0D / points;
                    Fx.particles(p, particle, new Vec3(center.x + Math.cos(a) * radius, center.y + 0.1D, center.z + Math.sin(a) * radius),
                            1, 0.0D, 0.05D, 0.0D, 0.0D);
                }
            });
        }
    }

    /** Simbolo del rituale: solo particelle (nessun blocco viene modificato). */
    private static void keeperSymbol(Ctx c) {
        Vec3 look = c.player().getLookAngle();
        Vec3 center = c.player().position().add(look.x * 7.0D, 0.0D, look.z * 7.0D);
        ring(c, center, ParticleTypes.END_ROD, 2.5D, 18);
        ring(c, center, ParticleTypes.END_ROD, 1.2D, 9);
        c.profile().remember(EntityKind.KEEPER, "symbol", c.now(), BlockPos.containing(center));
    }

    private static boolean hasItem(ServerPlayer p, Item item) {
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            if (p.getInventory().getItem(i).is(item)) return true;
        }
        return false;
    }

    private static boolean canOfferSigil(Ctx c) {
        PlayerProfile pr = c.profile();
        int next = pr.done(EntityKind.KEEPER) + 1;
        return next <= 4 && !pr.flags.contains("keeper_killed") && !pr.flags.contains("sigil_offered_" + next)
                && pr.countRecent(EntityKind.KEEPER, "apparition", 0L) >= 2
                && !hasItem(c.player(), ModItems.KEEPER_SIGIL.get());
    }

    /** Il Custode lascia un Sigillo (dopo averti osservato almeno due volte). Non avvia nessuna boss fight da solo. */
    private static void offerSigil(Ctx c) {
        int next = c.profile().done(EntityKind.KEEPER) + 1;
        Vec3 pos = Spots.find(c.level(), c.player().position(), 14.0D, 20.0D, 25, 4);
        if (pos == null) return;
        ApparitionEntity.spawn(c.level(), EntityKind.KEEPER, pos, ApparitionEntity.Behavior.VANISH_ON_APPROACH, 20 * 40, 6.0D, false);
        ItemEntity drop = new ItemEntity(c.level(), pos.x, pos.y + 0.3D, pos.z, new ItemStack(ModItems.KEEPER_SIGIL.get()));
        drop.setGlowingTag(true);
        c.level().addFreshEntity(drop);
        c.profile().flags.add("sigil_offered_" + next);
        Fx.say(c.player(), EntityKind.KEEPER, "keeper.offer");
    }

    private static void numbers404(Ctx c) {
        String[] lines = {"4 0 4", "404 404 404", "4 0 4  4 0 4", "ERR 404"};
        c.player().sendSystemMessage(Component.literal(lines[c.rnd().nextInt(lines.length)]).withStyle(ChatFormatting.GREEN));
        Vec3 pos = Spots.find(c.level(), c.player().position(), 18.0D, 28.0D, 25, 5);
        if (pos == null) return;
        ApparitionEntity.spawn(c.level(), EntityKind.ENTITY_404, pos, ApparitionEntity.Behavior.TIMED, 40, 0.0D, false);
        Fx.particles(c.player(), GREEN_DUST, pos.add(0.0D, 1.0D, 0.0D), 25, 0.4D, 0.8D, 0.4D, 0.0D);
        c.profile().remember(EntityKind.ENTITY_404, "apparition", c.now(), BlockPos.containing(pos));
    }

    private static void mageRunes(Ctx c) {
        Vec3 look = c.player().getLookAngle();
        Vec3 center = c.player().position().add(look.x * 9.0D, 0.0D, look.z * 9.0D);
        ring(c, center, ParticleTypes.ENCHANT, 2.0D, 16);
        Fx.sound(c.player(), SoundEvents.ILLUSIONER_MIRROR_MOVE, center, 1.0F, 1.0F);
        Vec3 pos = Spots.find(c.level(), center, 3.0D, 6.0D, 20, 4);
        if (pos != null) {
            ApparitionEntity.spawn(c.level(), EntityKind.MAGE, pos, ApparitionEntity.Behavior.VANISH_ON_APPROACH,
                    HorrorConfig.APPARITION_SECONDS.get() * 20, 10.0D, false);
        }
        c.profile().remember(EntityKind.MAGE, "runes", c.now(), BlockPos.containing(center));
    }
}
