package com.horroruniverse.event;

import com.horroruniverse.HorrorUniverse;
import net.minecraft.server.MinecraftServer;

import java.util.Comparator;
import java.util.PriorityQueue;

/** Piccolo scheduler sul tick del server per sequenze (passi, battiti...). Nessun timer reale, nessun thread. */
public final class HorrorScheduler {
    private record Task(long due, long order, Runnable action) {}

    private static final PriorityQueue<Task> QUEUE =
            new PriorityQueue<>(Comparator.comparingLong(Task::due).thenComparingLong(Task::order));
    private static long counter;

    private HorrorScheduler() {}

    public static void schedule(MinecraftServer server, int delayTicks, Runnable action) {
        QUEUE.add(new Task(server.getTickCount() + Math.max(0, delayTicks), counter++, action));
    }

    public static void tick(MinecraftServer server) {
        while (!QUEUE.isEmpty() && QUEUE.peek().due() <= server.getTickCount()) {
            Task t = QUEUE.poll();
            try {
                t.action().run();
            } catch (RuntimeException e) {
                HorrorUniverse.LOGGER.warn("Task horror fallito", e);
            }
        }
    }

    public static void clear() {
        QUEUE.clear();
    }
}
