package com.horroruniverse.entity;

import com.horroruniverse.config.HorrorConfig;
import com.horroruniverse.core.BossRules;
import com.horroruniverse.core.Fx;
import com.horroruniverse.core.FormRule;
import com.horroruniverse.core.HitDecision;
import com.horroruniverse.data.HorrorSavedData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Base dei boss: barra della salute, registrazione dei colpi secondo BossRules (Parte 9.5), abbandono
 * dello scontro, ricompense e progressione. La morte vanilla non c'e': ogni sconfitta e' narrativa.
 */
public abstract class AbstractHorrorBoss extends Monster {
    private static final EntityDataAccessor<Boolean> DATA_WINDOW =
            SynchedEntityData.defineId(AbstractHorrorBoss.class, EntityDataSerializers.BOOLEAN);

    protected final ServerBossEvent bossEvent =
            new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);
    protected final Set<UUID> participants = new HashSet<>();
    protected UUID challenger;
    protected int idleTicks;
    protected int deadChallengerTicks;
    protected boolean finished;
    private int lastDeflectTick = -100;

    protected AbstractHorrorBoss(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_WINDOW, false);
    }

    // ---- hook per le sottoclassi ----
    protected abstract FormRule currentRule();

    protected abstract void serverTick(ServerLevel level);

    protected abstract void completeFight(List<ServerPlayer> winners);

    protected boolean conditionMet() {
        return false;
    }

    protected boolean isImmuneNow() {
        return false;
    }

    /** Restituisce true se il colpo letale e' stato gestito (es. scelta finale del livello 4). */
    protected boolean interceptLethal(ServerPlayer killer) {
        return false;
    }

    protected float barProgress() {
        return Math.max(0.0F, Math.min(1.0F, getHealth() / getMaxHealth()));
    }

    protected void onLeave(ServerLevel level) {}

    // ---- finestra di vulnerabilita' (sincronizzata, usata anche dal renderer/effetti) ----
    public boolean isWindowOpen() {
        return this.entityData.get(DATA_WINDOW);
    }

    protected void setWindowOpen(boolean open) {
        this.entityData.set(DATA_WINDOW, open);
    }

    protected void scale(double health, double attack, double speed) {
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(health * HorrorConfig.BOSS_HEALTH.get());
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(attack * HorrorConfig.BOSS_DAMAGE.get());
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(speed * HorrorConfig.BOSS_SPEED.get());
        setHealth(getMaxHealth());
    }

    public void setChallenger(UUID id) {
        this.challenger = id;
        this.participants.add(id);
    }

    // ---- ciclo di vita ----
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || finished) return;
        bossEvent.setProgress(barProgress());
        if (tickCount % 20 == 0) checkAbandon((ServerLevel) level());
        if (!finished) serverTick((ServerLevel) level());
    }

    private void checkAbandon(ServerLevel sl) {
        Player near = sl.getNearestPlayer(this, 80.0D);
        idleTicks = near == null ? idleTicks + 20 : 0;
        if (idleTicks >= HorrorConfig.ABANDON_SECONDS.get() * 20) {
            leave(sl);
            return;
        }
        if (challenger != null) {
            Player c = sl.getPlayerByUUID(challenger);
            deadChallengerTicks = (c == null || !c.isAlive()) ? deadChallengerTicks + 20 : 0;
            if (deadChallengerTicks >= 100) leave(sl);
        }
    }

    /** Il boss se ne va senza che il giocatore abbia completato la prova (nessun progresso). */
    protected void leave(ServerLevel sl) {
        if (finished) return;
        finished = true;
        onLeave(sl);
        sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0D, getZ(), 30, 0.4D, 0.8D, 0.4D, 0.02D);
        bossEvent.removeAllPlayers();
        discard();
    }

    protected void finishNow(List<ServerPlayer> winners) {
        if (finished) return;
        finished = true;
        completeFight(winners);
        bossEvent.removeAllPlayers();
        discard();
    }

    protected List<ServerPlayer> winners() {
        List<ServerPlayer> list = new ArrayList<>();
        Set<UUID> ids = new HashSet<>(participants);
        if (challenger != null) ids.add(challenger);
        for (UUID id : ids) {
            Player p = level().getPlayerByUUID(id);
            if (p instanceof ServerPlayer sp && sp.isAlive() && sp.distanceToSqr(this) < 128.0D * 128.0D) list.add(sp);
        }
        return list;
    }

    @Override
    public void die(DamageSource source) {
        if (level().isClientSide || finished) return;
        finishNow(winners());
    }

    // ---- registrazione dei colpi ----
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide) return false;
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        FormRule rule = currentRule();
        Entity attacker = source.getEntity();
        if (rule == null || isImmuneNow() || attacker == null) {
            deflect(source, "immune");
            return false;
        }
        ItemStack weapon = ItemStack.EMPTY;
        if (attacker instanceof LivingEntity living && source.getDirectEntity() == attacker) {
            weapon = living.getMainHandItem();
        }
        HitDecision d = BossRules.evaluate(rule, weapon, amount, getMaxHealth(), isWindowOpen(), conditionMet());
        if (!d.accepted()) {
            deflect(source, d.reason());
            return false;
        }
        if (d.damage() >= getHealth() - 0.001F && attacker instanceof ServerPlayer sp && interceptLethal(sp)) {
            return true;
        }
        boolean hurt = super.hurt(source, d.damage());
        if (hurt && attacker instanceof ServerPlayer sp) participants.add(sp.getUUID());
        return hurt;
    }

    protected void deflect(DamageSource source, String reason) {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CRIT, getX(), getY() + 1.0D, getZ(), 6, 0.3D, 0.5D, 0.3D, 0.1D);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.HOSTILE, 0.6F, 1.4F);
        }
        if (source.getEntity() instanceof ServerPlayer sp && tickCount - lastDeflectTick > 15) {
            lastDeflectTick = tickCount;
            Fx.actionBar(sp, Component.translatable("horroruniverse.hint.deflect." + reason));
        }
    }

    // ---- utilita' ----
    protected ServerPlayer focus() {
        if (getTarget() instanceof ServerPlayer p && p.isAlive() && !p.isSpectator()) return p;
        Player near = level().getNearestPlayer(this, 64.0D);
        return near instanceof ServerPlayer sp ? sp : null;
    }

    protected boolean invasiveOk(ServerPlayer p) {
        return HorrorConfig.INVASIVE_EFFECTS.get() && HorrorSavedData.get(p.serverLevel().getServer()).profile(p).invasive;
    }

    protected void hitPlayer(ServerPlayer p, float damage, boolean magic) {
        float dmg = (float) (damage * HorrorConfig.BOSS_DAMAGE.get());
        p.hurt(magic ? damageSources().indirectMagic(this, this) : damageSources().mobAttack(this), dmg);
    }

    protected void giveOrDrop(ServerPlayer p, ItemStack stack) {
        if (stack.isEmpty()) return;
        p.getInventory().add(stack);
        if (!stack.isEmpty()) p.drop(stack, false);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        bossEvent.removeAllPlayers();
        super.remove(reason);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (challenger != null) tag.putUUID("Challenger", challenger);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Challenger")) {
            challenger = tag.getUUID("Challenger");
            participants.add(challenger);
        }
    }
}
