package com.horroruniverse.entity;

import com.horroruniverse.core.Fx;
import com.horroruniverse.registry.ModEntities;
import com.horroruniverse.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Proiettile della Perla del Rituale. Il colpo conta solo se il Custode (livello 5) ha la finestra aperta. */
public class RitualPearlEntity extends ThrowableItemProjectile {
    public RitualPearlEntity(EntityType<? extends RitualPearlEntity> type, Level level) {
        super(type, level);
    }

    public RitualPearlEntity(Level level, LivingEntity owner) {
        super(ModEntities.RITUAL_PEARL.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.RITUAL_PEARL.get();
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        if (result.getEntity() instanceof WhiteEyedKeeper keeper && getOwner() instanceof ServerPlayer sp) {
            if (!keeper.registerPearlHit(sp)) {
                Fx.actionBar(sp, Component.translatable("horroruniverse.hint.deflect.wrong_window"));
            }
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide && level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.PORTAL, getX(), getY(), getZ(), 12, 0.2D, 0.2D, 0.2D, 0.3D);
            discard();
        }
    }
}
