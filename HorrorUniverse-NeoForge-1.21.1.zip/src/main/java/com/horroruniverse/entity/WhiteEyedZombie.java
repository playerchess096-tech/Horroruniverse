package com.horroruniverse.entity;

import com.horroruniverse.core.BossRules;
import com.horroruniverse.core.HitDecision;
import com.horroruniverse.core.SpecialWeapon;
import com.horroruniverse.core.WeaponUtil;
import com.horroruniverse.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.UUID;

/**
 * Zombie dagli Occhi Bianchi (prova del contatto): piu' veloce, piu' resistente e piu' forte di uno zombie normale.
 * Non brucia al sole (immune al fuoco). Con le armi speciali segue la tabella: livello 3 = 2 colpi, livello 6 = 1 colpo.
 */
public class WhiteEyedZombie extends Zombie {
    private UUID owner;
    private int life = 20 * 180;

    public WhiteEyedZombie(EntityType<? extends WhiteEyedZombie> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 48.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D);
    }

    public void setOwner(UUID id) {
        this.owner = id;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        boolean gone = --life <= 0;
        if (!gone && owner != null && tickCount % 20 == 0) {
            Entity o = sl.getEntity(owner);
            gone = o == null || !o.isAlive();
        }
        if (gone) {
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0D, getZ(), 12, 0.3D, 0.6D, 0.3D, 0.02D);
            discard();
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && source.getEntity() instanceof LivingEntity attacker && source.getDirectEntity() == attacker) {
            ItemStack weapon = attacker.getMainHandItem();
            if (WeaponUtil.classify(weapon) != SpecialWeapon.NONE) {
                HitDecision d = BossRules.evaluate(BossRules.get("keeper_l2_zombie"), weapon, amount, getMaxHealth(), false, false);
                return d.accepted() && super.hurt(source, d.damage());
            }
        }
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && random.nextFloat() < 0.25F) {
            spawnAtLocation(ModItems.PALE_FRAGMENT.get());
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
    }
}
