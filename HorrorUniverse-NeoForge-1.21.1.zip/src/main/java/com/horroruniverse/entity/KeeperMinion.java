package com.horroruniverse.entity;

import com.horroruniverse.core.Fx;
import com.horroruniverse.core.HorrorEffects;
import com.horroruniverse.core.Spots;
import com.horroruniverse.registry.ModEffects;
import com.horroruniverse.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * Servitori del Custode (livello 3-4). Tre varianti con comportamenti e debolezze diversi:
 *  - Guardiano Pallido: corazzato e lento. Debole alle spalle (x1.75), resistente di fronte (x0.6).
 *  - Cavaliere del Fulmine: si carica e scarica una scossa ad area; subito dopo e' stordito e prende x2.
 *  - Sentinella dell'End: spara scariche dell'End e si teletrasporta; colpirla le impedisce di scappare per 3 s.
 */
public class KeeperMinion extends Monster {
    public enum Kind { PALE_GUARDIAN, LIGHTNING_KNIGHT, END_SENTINEL }

    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(KeeperMinion.class, EntityDataSerializers.INT);

    private UUID owner;
    private int life = 20 * 100;
    private int abilityCd = 60;
    private int stunned;
    private int noTeleport;
    private int charge;

    public KeeperMinion(EntityType<? extends KeeperMinion> type, Level level) {
        super(type, level);
        this.xpReward = 5;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 5.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.ARMOR, 0.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_KIND, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public Kind getKind() {
        return Kind.values()[Mth.clamp(this.entityData.get(DATA_KIND), 0, Kind.values().length - 1)];
    }

    public void setKind(Kind kind, UUID ownerId) {
        this.owner = ownerId;
        this.entityData.set(DATA_KIND, kind.ordinal());
        switch (kind) {
            case PALE_GUARDIAN -> stats(60.0D, 0.22D, 7.0D, 6.0D, 0.6D);
            case LIGHTNING_KNIGHT -> {
                stats(40.0D, 0.30D, 5.0D, 0.0D, 0.1D);
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
            }
            case END_SENTINEL -> stats(35.0D, 0.26D, 3.0D, 0.0D, 0.0D);
        }
    }

    private void stats(double hp, double speed, double attack, double armor, double knockbackRes) {
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(hp);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(speed);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(attack);
        getAttribute(Attributes.ARMOR).setBaseValue(armor);
        getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(knockbackRes);
        setHealth((float) hp);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        if (--life <= 0) {
            poof(sl);
            return;
        }
        if (tickCount % 20 == 0 && owner != null) {
            Entity o = sl.getEntity(owner);
            if (o == null || !o.isAlive()) {
                poof(sl);
                return;
            }
        }
        if (abilityCd > 0) abilityCd--;
        if (stunned > 0) stunned--;
        if (noTeleport > 0) noTeleport--;
        LivingEntity target = getTarget();
        switch (getKind()) {
            case LIGHTNING_KNIGHT -> knight(sl, target);
            case END_SENTINEL -> sentinel(sl, target);
            default -> {}
        }
    }

    private void poof(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0D, getZ(), 15, 0.3D, 0.6D, 0.3D, 0.02D);
        discard();
    }

    private void knight(ServerLevel sl, LivingEntity target) {
        if (charge > 0) {
            charge--;
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1.0D, getZ(), 4, 0.5D, 0.8D, 0.5D, 0.05D);
            if (charge == 0) {
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.8F, 1.5F);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1.0D, getZ(), 40, 1.5D, 0.8D, 1.5D, 0.3D);
                for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(3.5D))) {
                    p.hurt(damageSources().indirectMagic(this, this), 5.0F);
                    HorrorEffects.apply(p, ModEffects.SHOCK, 80, 0);
                }
                stunned = 60;
                abilityCd = 140;
                addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
            }
            return;
        }
        if (abilityCd == 0 && target != null && distanceTo(target) < 6.0F && stunned == 0) {
            charge = 20;
        }
    }

    private void sentinel(ServerLevel sl, LivingEntity target) {
        if (target == null) return;
        double dist = distanceTo(target);
        if (noTeleport == 0 && dist < 4.0D) {
            Vec3 spot = Spots.find(sl, target.position(), 8.0D, 12.0D, 15, 3);
            if (spot != null) {
                sl.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1.0D, getZ(), 20, 0.3D, 0.6D, 0.3D, 0.4D);
                moveTo(spot.x, spot.y, spot.z, getYRot(), getXRot());
                getNavigation().stop();
                sl.playSound(null, spot.x, spot.y, spot.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 0.8F, 1.0F);
                noTeleport = 100;
            }
            return;
        }
        if (abilityCd == 0 && dist > 5.0D && dist < 24.0D && hasLineOfSight(target)) {
            Vec3 from = new Vec3(getX(), getEyeY() - 0.2D, getZ());
            Vec3 to = target.getEyePosition();
            for (int i = 0; i <= 12; i++) {
                Vec3 p = from.lerp(to, i / 12.0D);
                sl.sendParticles(ParticleTypes.PORTAL, p.x, p.y, p.z, 2, 0.05D, 0.05D, 0.05D, 0.0D);
            }
            target.hurt(damageSources().indirectMagic(this, this), 4.0F);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.ENDERMAN_STARE, SoundSource.HOSTILE, 0.6F, 1.6F);
            abilityCd = 70;
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        float a = amount;
        Entity attacker = source.getEntity();
        switch (getKind()) {
            case PALE_GUARDIAN -> {
                if (attacker != null) {
                    Vec3 toAttacker = attacker.position().subtract(position()).normalize();
                    Vec3 facing = Vec3.directionFromRotation(0.0F, this.yBodyRot);
                    double dot = facing.dot(toAttacker);
                    if (dot < -0.3D) a *= 1.75F;
                    else if (dot > 0.3D) a *= 0.6F;
                }
            }
            case LIGHTNING_KNIGHT -> {
                if (stunned > 0) a *= 2.0F;
            }
            case END_SENTINEL -> noTeleport = 60;
        }
        return super.hurt(source, a);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && random.nextFloat() < 0.15F) {
            spawnAtLocation(ModItems.PALE_FRAGMENT.get());
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return true;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Kind", getKind().ordinal());
        tag.putInt("Life", life);
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_KIND, Mth.clamp(tag.getInt("Kind"), 0, Kind.values().length - 1));
        if (tag.contains("Life")) life = tag.getInt("Life");
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
    }
}
