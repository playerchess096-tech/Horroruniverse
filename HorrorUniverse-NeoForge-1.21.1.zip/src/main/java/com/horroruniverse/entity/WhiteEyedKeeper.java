package com.horroruniverse.entity;

import com.horroruniverse.config.HorrorConfig;
import com.horroruniverse.core.BossRules;
import com.horroruniverse.core.EntityKind;
import com.horroruniverse.core.FormRule;
import com.horroruniverse.core.Fx;
import com.horroruniverse.core.HorrorEffects;
import com.horroruniverse.core.Spots;
import com.horroruniverse.data.HorrorSavedData;
import com.horroruniverse.data.PlayerProfile;
import com.horroruniverse.registry.ModEffects;
import com.horroruniverse.registry.ModEntities;
import com.horroruniverse.registry.ModItems;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Il Custode dagli Occhi Bianchi. Livello 1 Guardiano, 2 Prova del Contatto, 3 Scettro Elettrico,
 * 4 Custode Supremo (con scelta finale), 5 Rituale Proibito (10 Perle del Rituale in finestra valida).
 */
public class WhiteEyedKeeper extends AbstractHorrorBoss {
    private static final EntityDataAccessor<Integer> DATA_LEVEL =
            SynchedEntityData.defineId(WhiteEyedKeeper.class, EntityDataSerializers.INT);

    private static final int CD_CONFUSE = 0, CD_TELEPORT = 1, CD_SUMMON = 2, CD_STRIKE = 3, CD_ARC = 4, CD_ZONE = 5,
            CD_LAUNCH = 6, CD_EYES = 7, CD_EFFECT = 8, CD_SWORD = 9, CD_ENDERMEN = 10, CD_ZOMBIES = 11, CD_CLONES = 12;
    private static final String TEMP_TAG = "horror_temp";

    private final int[] cd = new int[13];
    private final List<UUID> minions = new ArrayList<>();
    private final List<Strike> strikes = new ArrayList<>();
    private final List<Zone> zones = new ArrayList<>();

    private record Strike(Vec3 pos, int due, boolean ender) {}

    private static final class Zone {
        final Vec3 pos;
        int ticks;

        Zone(Vec3 pos, int ticks) {
            this.pos = pos;
            this.ticks = ticks;
        }
    }

    // livello 1
    private int wave;
    private int waveTimer;
    private int summonCounter;
    // livello 2
    private int contacts;
    private int contactCd;
    private int blinkTelegraph;
    private int zombieCd;
    private int zombieSpawns;
    private UUID zombieId;
    // livelli 3-4
    private int phase;
    private boolean choice;
    private boolean choiceKill;
    private int choiceTicks;
    // livello 5
    private int introTicks;
    private int pearlHits;
    private int teleportsLeft = 3;
    private int nextTeleport = 40;
    private int windowTicks;
    private int pearlsGiven;
    private int swordTicks;
    private int eyeTicks;

    public WhiteEyedKeeper(EntityType<? extends WhiteEyedKeeper> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 100.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_LEVEL, 1);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new KeeperMeleeGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    private static final class KeeperMeleeGoal extends MeleeAttackGoal {
        private final WhiteEyedKeeper keeper;

        KeeperMeleeGoal(WhiteEyedKeeper keeper) {
            super(keeper, 1.1D, false);
            this.keeper = keeper;
        }

        @Override
        public boolean canUse() {
            return keeper.canMelee() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return keeper.canMelee() && super.canContinueToUse();
        }
    }

    private boolean canMelee() {
        int lvl = getBossLevel();
        if (finished || choice || lvl == 2 || isWindowOpen()) return false;
        return lvl != 5 || swordTicks > 0;
    }

    public int getBossLevel() {
        return this.entityData.get(DATA_LEVEL);
    }

    public void setBossLevel(int lvl) {
        int l = Mth.clamp(lvl, 1, 5);
        this.entityData.set(DATA_LEVEL, l);
        switch (l) {
            case 1 -> {
                scale(60.0D, 1.0D, 0.28D);
                setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
                setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.LEATHER_CHESTPLATE));
                setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.LEATHER_LEGGINGS));
                setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.LEATHER_BOOTS));
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.WOODEN_SWORD));
            }
            case 2 -> scale(40.0D, 0.0D, 0.30D);
            case 3 -> {
                scale(220.0D, 7.0D, 0.30D);
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.ELECTRIC_SCEPTER.get()));
            }
            case 4 -> {
                scale(420.0D, 9.0D, 0.32D);
                setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.ELECTRIC_SCEPTER.get()));
            }
            default -> scale(350.0D, 8.0D, 0.32D);
        }
        bossEvent.setName(Component.translatable("horroruniverse.boss.keeper." + l));
        bossEvent.setColor(switch (l) {
            case 3 -> BossEvent.BossBarColor.BLUE;
            case 4 -> BossEvent.BossBarColor.YELLOW;
            case 5 -> BossEvent.BossBarColor.PURPLE;
            default -> BossEvent.BossBarColor.WHITE;
        });
        bossEvent.setOverlay(l == 5 ? BossEvent.BossBarOverlay.NOTCHED_10 : BossEvent.BossBarOverlay.PROGRESS);
    }

    // ------------------------------------------------------------------ regole
    @Override
    protected FormRule currentRule() {
        return BossRules.get("keeper_l" + getBossLevel());
    }

    @Override
    protected float barProgress() {
        int lvl = getBossLevel();
        if (lvl == 2) return Math.min(1.0F, contacts / 3.0F);
        if (lvl == 5) return Math.max(0.0F, 1.0F - pearlHits / 10.0F);
        return super.barProgress();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && choice) {
            // scelta finale (livello 4): colpirlo di nuovo lo uccide definitivamente
            if (source.getEntity() instanceof ServerPlayer sp && source.getDirectEntity() == sp) decide(sp, true);
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected boolean interceptLethal(ServerPlayer killer) {
        if (getBossLevel() != 4 || choice || !(level() instanceof ServerLevel sl)) return false;
        choice = true;
        choiceTicks = 20 * 45;
        setHealth(1.0F);
        participants.add(killer.getUUID());
        despawnMinions(sl);
        strikes.clear();
        zones.clear();
        getNavigation().stop();
        for (ServerPlayer p : nearbyPlayers(sl)) Fx.say(p, EntityKind.KEEPER, "keeper.l4.choice");
        return true;
    }

    private void decide(ServerPlayer sp, boolean kill) {
        if (finished) return;
        choiceKill = kill;
        if (sp != null) participants.add(sp.getUUID());
        finishNow(winners());
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return super.mobInteract(player, hand);
        if (getBossLevel() == 2 && !finished) {
            if (!level().isClientSide && player instanceof ServerPlayer sp) tryContact(sp);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (choice) {
            if (!level().isClientSide && player instanceof ServerPlayer sp && sp.getMainHandItem().isEmpty()) decide(sp, false);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------------ ciclo principale
    @Override
    protected void serverTick(ServerLevel sl) {
        for (int i = 0; i < cd.length; i++) {
            if (cd[i] > 0) cd[i]--;
        }
        if (tickCount % 20 == 0) pruneMinions(sl);
        tickStrikes(sl);
        tickZones(sl);
        switch (getBossLevel()) {
            case 1 -> tickL1(sl);
            case 2 -> tickL2(sl);
            case 3, 4 -> tickL34(sl);
            default -> tickL5(sl);
        }
    }

    public void onArrival(ServerLevel sl) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
        if (bolt != null) {
            bolt.moveTo(getX(), getY(), getZ());
            bolt.setVisualOnly(true);
            sl.addFreshEntity(bolt);
        }
        for (ServerPlayer p : nearbyPlayers(sl)) Fx.say(p, EntityKind.KEEPER, "keeper.l" + getBossLevel() + ".intro");
    }

    // ------------------------------------------------------------------ livello 1: il Guardiano
    private void tickL1(ServerLevel sl) {
        ServerPlayer target = focus();
        if (target == null) return;
        if (wave == 0) {
            spawnZombieWave(sl, target, 3);
            wave = 1;
        }
        float frac = getHealth() / getMaxHealth();
        if (wave < 3) {
            waveTimer++;
            boolean hpTrigger = frac <= (wave == 1 ? 0.66F : 0.33F);
            boolean idleTrigger = minions.isEmpty() && waveTimer > 140;
            if (hpTrigger || idleTrigger) {
                wave++;
                waveTimer = 0;
                spawnZombieWave(sl, target, 2 + wave);
                Fx.say(target, EntityKind.KEEPER, "keeper.l1.wave");
            }
        }
        if (cd[CD_CONFUSE] == 0 && distanceTo(target) < 14.0F) {
            Vec3 spot = Spots.find(sl, Spots.behind(target, 3.0D), 0.0D, 2.0D, 8, 2);
            if (spot != null) {
                blinkTo(sl, spot);
                if (invasiveOk(target)) HorrorEffects.apply(target, MobEffects.CONFUSION, 80, 0);
            }
            cd[CD_CONFUSE] = HorrorEffects.cd(260);
        }
        if (cd[CD_TELEPORT] == 0 && frac < 0.5F && distanceTo(target) < 4.0F) {
            blinkTo(sl, Spots.find(sl, target.position(), 10.0D, 14.0D, 20, 3));
            cd[CD_TELEPORT] = HorrorEffects.cd(400);
        }
    }

    private void spawnZombieWave(ServerLevel sl, ServerPlayer target, int count) {
        int slots = HorrorConfig.MAX_MINIONS.get() - minions.size();
        for (int i = 0; i < Math.min(count, slots); i++) {
            Vec3 pos = Spots.find(sl, target.position(), 4.0D, 9.0D, 20, 3);
            if (pos == null) continue;
            Zombie z = EntityType.ZOMBIE.create(sl);
            if (z == null) continue;
            z.moveTo(pos.x, pos.y, pos.z, random.nextFloat() * 360.0F, 0.0F);
            z.setTarget(target);
            z.setPersistenceRequired();
            sl.addFreshEntity(z);
            minions.add(z.getUUID());
        }
    }

    // ------------------------------------------------------------------ livello 2: la Prova del Contatto
    private void tickL2(ServerLevel sl) {
        ServerPlayer target = focus();
        if (target == null) return;
        if (contactCd > 0) contactCd--;
        if (zombieCd > 0) zombieCd--;
        Entity z = zombieId == null ? null : sl.getEntity(zombieId);
        boolean zAlive = z != null && z.isAlive();
        if (!zAlive && zombieCd == 0 && zombieSpawns < 4) {
            Vec3 pos = Spots.find(sl, target.position(), 6.0D, 10.0D, 20, 3);
            WhiteEyedZombie wz = pos == null ? null : ModEntities.WHITE_EYED_ZOMBIE.get().create(sl);
            if (wz != null) {
                wz.moveTo(pos.x, pos.y, pos.z, random.nextFloat() * 360.0F, 0.0F);
                wz.setOwner(getUUID());
                wz.setTarget(target);
                wz.setPersistenceRequired();
                sl.addFreshEntity(wz);
                zombieId = wz.getUUID();
                zombieSpawns++;
                zombieCd = 240; // ricompare solo con regole controllate: max 4 comparse, 12 s l'una dall'altra
            }
        }
        if (blinkTelegraph > 0) {
            sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.0D, getZ(), 4, 0.3D, 0.8D, 0.3D, 0.02D);
            if (--blinkTelegraph == 0) blinkTo(sl, Spots.find(sl, target.position(), 5.0D, 9.0D, 20, 3));
        } else if (cd[CD_TELEPORT] == 0 && distanceTo(target) < 5.5F) {
            blinkTelegraph = 14; // segnale visibile prima dello spostamento: il giocatore puo' toccare in tempo
            cd[CD_TELEPORT] = HorrorEffects.cd(130);
        }
    }

    /** Ogni contatto e' un clic destro reale entro 3.8 blocchi; dopo ogni contatto il Custode si sposta. */
    private void tryContact(ServerPlayer sp) {
        if (contactCd > 0 || finished || distanceTo(sp) > 3.8F || !(level() instanceof ServerLevel sl)) return;
        contacts++;
        contactCd = 50;
        participants.add(sp.getUUID());
        sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.0D, getZ(), 20, 0.3D, 0.6D, 0.3D, 0.05D);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 1.0F, 1.2F);
        Fx.actionBar(sp, Component.translatable("horroruniverse.line.keeper.l2.touch", contacts, 3));
        if (contacts >= 3) {
            finishNow(winners());
            return;
        }
        blinkTelegraph = 0;
        blinkTo(sl, Spots.find(sl, sp.position(), 7.0D, 11.0D, 25, 3));
        cd[CD_TELEPORT] = HorrorEffects.cd(60);
    }

    // ------------------------------------------------------------------ livelli 3 e 4: scettro elettrico / supremo
    private void tickL34(ServerLevel sl) {
        if (choice) {
            if (--choiceTicks <= 0) decide(null, false);
            else if (choiceTicks % 200 == 0) {
                for (ServerPlayer p : nearbyPlayers(sl)) Fx.hint(p, "keeper.choice");
            }
            return;
        }
        ServerPlayer target = focus();
        if (target == null) return;
        int lvl = getBossLevel();
        float frac = getHealth() / getMaxHealth();
        int ph = frac <= 0.33F ? 2 : frac <= 0.66F ? 1 : 0;
        if (ph > phase) {
            phase = ph;
            phaseShift(sl);
        }
        double dist = distanceTo(target);
        if (cd[CD_STRIKE] == 0 && dist < 45.0D) {
            queueStrike(target.position(), false);
            if (lvl == 4 && phase >= 1) queueStrike(randomNear(target.position(), 5.0D), false);
            cd[CD_STRIKE] = HorrorEffects.cd(lvl == 4 ? 90 : 120);
        }
        if (cd[CD_ARC] == 0 && dist > 5.0D && dist < 30.0D && hasLineOfSight(target)) {
            arc(sl, target, lvl == 4 ? 5.0F : 4.0F);
            cd[CD_ARC] = HorrorEffects.cd(70);
        }
        if (cd[CD_SUMMON] == 0) {
            summonWave(sl, target);
            cd[CD_SUMMON] = HorrorEffects.cd(520 - phase * 80);
        }
        if (cd[CD_ZONE] == 0 && dist < 30.0D) {
            zones.add(new Zone(target.position(), 160));
            cd[CD_ZONE] = HorrorEffects.cd(320);
        }
        if (cd[CD_TELEPORT] == 0 && dist < 3.5D) {
            blinkTo(sl, Spots.find(sl, target.position(), 8.0D, 12.0D, 20, 3));
            cd[CD_TELEPORT] = HorrorEffects.cd(160);
        }
        if ((lvl == 4 || phase >= 1) && cd[CD_EFFECT] == 0 && dist < 16.0D) {
            HorrorEffects.apply(target, MobEffects.MOVEMENT_SLOWDOWN, 100, 0);
            if (lvl == 4) HorrorEffects.apply(target, MobEffects.WEAKNESS, 100, 0);
            if (phase >= 2 && invasiveOk(target)) HorrorEffects.apply(target, MobEffects.DARKNESS, 100, 0);
            cd[CD_EFFECT] = HorrorEffects.cd(360);
        }
    }

    private void phaseShift(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.FLASH, getX(), getY() + 1.5D, getZ(), 3, 0.2D, 0.2D, 0.2D, 0.0D);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 3.0F, 0.9F);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(getAttributeBaseValue(Attributes.MOVEMENT_SPEED) * 1.08D);
        cd[CD_SUMMON] = 0;
        for (ServerPlayer p : nearbyPlayers(sl)) Fx.say(p, EntityKind.KEEPER, "keeper.l" + getBossLevel() + ".phase");
    }

    private void summonWave(ServerLevel sl, ServerPlayer target) {
        int slots = HorrorConfig.MAX_MINIONS.get() - minions.size();
        if (slots <= 0) return;
        KeeperMinion.Kind[] kinds = KeeperMinion.Kind.values();
        int n = Math.min(slots, (getBossLevel() == 4 ? 3 : 2) + (phase >= 2 ? 1 : 0));
        for (int i = 0; i < n; i++) {
            Vec3 pos = Spots.find(sl, target.position(), 5.0D, 10.0D, 20, 3);
            if (pos == null) continue;
            if (getBossLevel() == 4 && phase >= 1 && i == n - 1) {
                // creature presenti in Minecraft (livello 4)
                Zombie z = (random.nextBoolean() ? EntityType.ZOMBIE : EntityType.HUSK).create(sl);
                if (z == null) continue;
                z.moveTo(pos.x, pos.y, pos.z, random.nextFloat() * 360.0F, 0.0F);
                z.setTarget(target);
                z.setPersistenceRequired();
                sl.addFreshEntity(z);
                minions.add(z.getUUID());
                continue;
            }
            KeeperMinion m = ModEntities.KEEPER_MINION.get().create(sl);
            if (m == null) continue;
            m.moveTo(pos.x, pos.y, pos.z, random.nextFloat() * 360.0F, 0.0F);
            m.setKind(kinds[summonCounter++ % kinds.length], getUUID());
            m.setTarget(target);
            m.setPersistenceRequired();
            sl.addFreshEntity(m);
            minions.add(m.getUUID());
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 1.0D, pos.z, 15, 0.3D, 0.6D, 0.3D, 0.1D);
        }
    }

    // ------------------------------------------------------------------ livello 5: il Rituale Proibito
    private void tickL5(ServerLevel sl) {
        ServerPlayer target = focus();
        if (target == null) return;
        if (introTicks < 80) {
            introTicks++;
            if (introTicks == 40) givePearls(target, 2);
            return;
        }
        if (swordTicks > 0 && --swordTicks == 0) setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        if (eyeTicks > 0 && --eyeTicks == 0) {
            for (ServerPlayer p : nearbyPlayers(sl)) removeTempEyes(p);
        }
        if (isWindowOpen()) {
            getNavigation().stop();
            if (tickCount % 4 == 0) {
                sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.0D, getZ(), 3, 0.4D, 0.9D, 0.4D, 0.02D);
            }
            if (--windowTicks <= 0) {
                closeWindow();
                for (ServerPlayer p : nearbyPlayers(sl)) Fx.say(p, EntityKind.KEEPER, "keeper.l5.miss");
                spawnEndermen(sl, target, 1);
                blinkTo(sl, Spots.find(sl, target.position(), 8.0D, 14.0D, 20, 3));
            }
            return;
        }
        if (nextTeleport > 0) nextTeleport--;
        if (nextTeleport == 0) {
            if (teleportsLeft > 0) {
                blinkTo(sl, Spots.find(sl, target.position(), 6.0D, 14.0D, 25, 4));
                teleportsLeft--;
                nextTeleport = 40 + random.nextInt(30);
            } else {
                openWindow(sl, target);
                return;
            }
        }
        double dist = distanceTo(target);
        if (cd[CD_ENDERMEN] == 0) {
            spawnEndermen(sl, target, 2);
            cd[CD_ENDERMEN] = HorrorEffects.cd(420);
        }
        if (cd[CD_ZOMBIES] == 0) {
            spawnVanilla(sl, target, EntityType.ZOMBIE, 2);
            cd[CD_ZOMBIES] = HorrorEffects.cd(560);
        }
        if (cd[CD_CLONES] == 0 && HorrorConfig.MAX_CLONES.get() > 0) {
            for (int i = 0; i < HorrorConfig.MAX_CLONES.get(); i++) {
                Vec3 pos = Spots.find(sl, target.position(), 6.0D, 12.0D, 20, 3);
                if (pos != null) {
                    ApparitionEntity.spawn(sl, EntityKind.KEEPER, pos, ApparitionEntity.Behavior.TIMED, 20 * 25, 0.0D, true);
                }
            }
            cd[CD_CLONES] = HorrorEffects.cd(500);
        }
        if (cd[CD_STRIKE] == 0 && dist < 45.0D) {
            queueStrike(target.position(), true);
            cd[CD_STRIKE] = HorrorEffects.cd(150);
        }
        if (cd[CD_LAUNCH] == 0 && dist < 7.0D && invasiveOk(target)) {
            // lancio in aria: caduta lenta per non uccidere il giocatore
            target.setDeltaMovement(target.getDeltaMovement().add(0.0D, 1.1D, 0.0D));
            target.hurtMarked = true;
            target.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0));
            sl.sendParticles(ParticleTypes.DRAGON_BREATH, target.getX(), target.getY(), target.getZ(), 30, 0.4D, 0.2D, 0.4D, 0.05D);
            cd[CD_LAUNCH] = HorrorEffects.cd(380);
        }
        if (cd[CD_EYES] == 0 && invasiveOk(target)) {
            giveTempEyes(target);
            eyeTicks = 160;
            cd[CD_EYES] = HorrorEffects.cd(640);
        }
        if (cd[CD_SWORD] == 0) {
            setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
            swordTicks = 120;
            cd[CD_SWORD] = HorrorEffects.cd(300);
        }
    }

    private void openWindow(ServerLevel sl, ServerPlayer target) {
        Vec3 spot = Spots.find(sl, target.position(), 7.0D, 10.0D, 25, 3);
        if (spot != null) blinkTo(sl, spot);
        setWindowOpen(true);
        windowTicks = 140;
        addEffect(new MobEffectInstance(MobEffects.GLOWING, 140, 0, false, false));
        for (ServerPlayer p : nearbyPlayers(sl)) {
            Fx.say(p, EntityKind.KEEPER, "keeper.l5.window");
            if (pearlsGiven < 30) givePearls(p, 2);
        }
    }

    private void closeWindow() {
        setWindowOpen(false);
        windowTicks = 0;
        removeEffect(MobEffects.GLOWING);
        teleportsLeft = 3 + random.nextInt(2);
        nextTeleport = 30;
    }

    /** Chiamato dalla Perla del Rituale: conta solo con la finestra aperta (Parte 2.7: la sequenza e' reale). */
    public boolean registerPearlHit(ServerPlayer sp) {
        if (finished || getBossLevel() != 5 || !isWindowOpen() || !(level() instanceof ServerLevel sl)) return false;
        participants.add(sp.getUUID());
        pearlHits++;
        closeWindow();
        sl.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1.0D, getZ(), 40, 0.4D, 0.8D, 0.4D, 0.6D);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.ENDERMAN_STARE, SoundSource.HOSTILE, 1.0F, 0.7F);
        Fx.actionBar(sp, Component.translatable("horroruniverse.line.keeper.l5.hit", pearlHits, 10));
        if (pearlHits >= 10) {
            finishNow(winners());
            return true;
        }
        blinkTo(sl, Spots.find(sl, sp.position(), 8.0D, 14.0D, 20, 3));
        return true;
    }

    private void givePearls(ServerPlayer p, int n) {
        pearlsGiven += n;
        giveOrDrop(p, new ItemStack(ModItems.RITUAL_PEARL.get(), n));
    }

    private void giveTempEyes(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < 3; i++) {
            int slot = inv.getFreeSlot();
            if (slot < 0) return;
            ItemStack eye = new ItemStack(Items.ENDER_EYE);
            CompoundTag tag = new CompoundTag();
            tag.putBoolean(TEMP_TAG, true);
            eye.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            inv.setItem(slot, eye);
        }
    }

    /** Rimuove SOLO gli Occhi di Ender temporanei creati dal Custode (reversibile, nessun oggetto reale perso). */
    private void removeTempEyes(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.is(Items.ENDER_EYE)) {
                CustomData data = s.get(DataComponents.CUSTOM_DATA);
                if (data != null && data.contains(TEMP_TAG)) inv.setItem(i, ItemStack.EMPTY);
            }
        }
    }

    private void spawnEndermen(ServerLevel sl, ServerPlayer target, int count) {
        spawnVanilla(sl, target, EntityType.ENDERMAN, count);
    }

    private void spawnVanilla(ServerLevel sl, ServerPlayer target, EntityType<? extends net.minecraft.world.entity.Mob> type, int count) {
        int slots = HorrorConfig.MAX_MINIONS.get() - minions.size();
        for (int i = 0; i < Math.min(count, slots); i++) {
            Vec3 pos = Spots.find(sl, target.position(), 6.0D, 12.0D, 20, 3);
            if (pos == null) continue;
            net.minecraft.world.entity.Mob m = type.create(sl);
            if (m == null) continue;
            m.moveTo(pos.x, pos.y, pos.z, random.nextFloat() * 360.0F, 0.0F);
            m.setTarget(target);
            m.setPersistenceRequired();
            sl.addFreshEntity(m);
            minions.add(m.getUUID());
            sl.sendParticles(ParticleTypes.PORTAL, pos.x, pos.y + 1.0D, pos.z, 20, 0.3D, 0.6D, 0.3D, 0.4D);
        }
    }

    // ------------------------------------------------------------------ abilita' elettriche condivise
    private void queueStrike(Vec3 pos, boolean ender) {
        strikes.add(new Strike(pos, tickCount + 30, ender));
        if (level() instanceof ServerLevel sl) {
            for (ServerPlayer p : nearbyPlayers(sl)) {
                Fx.sound(p, SoundEvents.LIGHTNING_BOLT_THUNDER, pos, 0.5F, 1.6F);
            }
        }
    }

    private void tickStrikes(ServerLevel sl) {
        Iterator<Strike> it = strikes.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            if (tickCount % 3 == 0) {
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4.0D;
                    sl.sendParticles(s.ender() ? ParticleTypes.PORTAL : ParticleTypes.ELECTRIC_SPARK,
                            s.pos().x + Math.cos(a) * 3.0D, s.pos().y + 0.2D, s.pos().z + Math.sin(a) * 3.0D, 1, 0.0D, 0.1D, 0.0D, 0.0D);
                }
            }
            if (tickCount < s.due()) continue;
            it.remove();
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
            if (bolt != null) {
                bolt.moveTo(s.pos().x, s.pos().y, s.pos().z);
                bolt.setVisualOnly(true);
                sl.addFreshEntity(bolt);
            }
            float dmg = getBossLevel() >= 4 ? 9.0F : 7.0F;
            for (Player p : sl.getEntitiesOfClass(Player.class, new AABB(s.pos(), s.pos()).inflate(3.2D))) {
                if (p instanceof ServerPlayer sp) {
                    hitPlayer(sp, dmg, true);
                    HorrorEffects.apply(sp, ModEffects.SHOCK, 100, 0);
                }
            }
        }
    }

    private void arc(ServerLevel sl, ServerPlayer target, float damage) {
        Vec3 from = new Vec3(getX(), getEyeY() - 0.2D, getZ());
        Vec3 to = target.getEyePosition();
        for (int i = 0; i <= 14; i++) {
            Vec3 p = from.lerp(to, i / 14.0D);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0.02D, 0.02D, 0.02D, 0.0D);
        }
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.6F, 1.7F);
        hitPlayer(target, damage, true);
        if (random.nextFloat() < 0.4F) HorrorEffects.apply(target, ModEffects.SHOCK, 80, 0);
    }

    private void tickZones(ServerLevel sl) {
        Iterator<Zone> it = zones.iterator();
        while (it.hasNext()) {
            Zone z = it.next();
            if (--z.ticks <= 0) {
                it.remove();
                continue;
            }
            if (tickCount % 6 == 0) {
                for (int i = 0; i < 12; i++) {
                    double a = i * Math.PI / 6.0D;
                    sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, z.pos.x + Math.cos(a) * 3.5D, z.pos.y + 0.1D,
                            z.pos.z + Math.sin(a) * 3.5D, 1, 0.0D, 0.05D, 0.0D, 0.0D);
                }
            }
            if (tickCount % 20 == 0) {
                for (Player p : sl.getEntitiesOfClass(Player.class, new AABB(z.pos, z.pos).inflate(3.5D, 2.0D, 3.5D))) {
                    if (p instanceof ServerPlayer sp) {
                        hitPlayer(sp, 2.5F, true);
                        HorrorEffects.apply(sp, ModEffects.SHOCK, 60, 0);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ utilita'
    private void blinkTo(ServerLevel sl, Vec3 p) {
        if (p == null) return;
        sl.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1.0D, getZ(), 30, 0.3D, 0.6D, 0.3D, 0.5D);
        moveTo(p.x, p.y, p.z, getYRot(), getXRot());
        getNavigation().stop();
        sl.sendParticles(ParticleTypes.PORTAL, p.x, p.y + 1.0D, p.z, 30, 0.3D, 0.6D, 0.3D, 0.5D);
        sl.playSound(null, p.x, p.y, p.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0F, 0.8F);
    }

    private Vec3 randomNear(Vec3 center, double r) {
        return center.add((random.nextDouble() - 0.5D) * 2.0D * r, 0.0D, (random.nextDouble() - 0.5D) * 2.0D * r);
    }

    private List<ServerPlayer> nearbyPlayers(ServerLevel sl) {
        return sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(64.0D));
    }

    private void pruneMinions(ServerLevel sl) {
        minions.removeIf(id -> {
            Entity e = sl.getEntity(id);
            return e == null || !e.isAlive();
        });
    }

    private void despawnMinions(ServerLevel sl) {
        for (UUID id : minions) {
            Entity e = sl.getEntity(id);
            if (e != null) {
                sl.sendParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + 1.0D, e.getZ(), 10, 0.3D, 0.6D, 0.3D, 0.02D);
                e.discard();
            }
        }
        minions.clear();
        if (zombieId != null) {
            Entity z = sl.getEntity(zombieId);
            if (z != null) z.discard();
        }
    }

    @Override
    protected void onLeave(ServerLevel sl) {
        despawnMinions(sl);
        for (ServerPlayer p : nearbyPlayers(sl)) {
            removeTempEyes(p);
            Fx.say(p, EntityKind.KEEPER, "keeper.leave");
        }
    }

    public static boolean activeNear(ServerLevel sl, Vec3 pos, double radius) {
        return !sl.getEntitiesOfClass(WhiteEyedKeeper.class, new AABB(pos, pos).inflate(radius)).isEmpty();
    }

    public static WhiteEyedKeeper summon(ServerPlayer sp, int lvl) {
        ServerLevel sl = sp.serverLevel();
        Vec3 pos = Spots.find(sl, sp.position(), 6.0D, 10.0D, 30, 4);
        if (pos == null) return null;
        WhiteEyedKeeper k = ModEntities.KEEPER.get().create(sl);
        if (k == null) return null;
        float yaw = (float) (Mth.atan2(sp.getZ() - pos.z, sp.getX() - pos.x) * (180.0D / Math.PI)) - 90.0F;
        k.moveTo(pos.x, pos.y, pos.z, yaw, 0.0F);
        k.setBossLevel(lvl);
        k.setChallenger(sp.getUUID());
        k.setPersistenceRequired();
        sl.addFreshEntity(k);
        k.onArrival(sl);
        return k;
    }

    // ------------------------------------------------------------------ vittoria e ricompense
    @Override
    protected void completeFight(List<ServerPlayer> winners) {
        if (!(level() instanceof ServerLevel sl)) return;
        int lvl = getBossLevel();
        despawnMinions(sl);
        sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.0D, getZ(), 40, 0.5D, 1.0D, 0.5D, 0.1D);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0F, 0.5F);
        HorrorSavedData data = HorrorSavedData.get(sl.getServer());
        for (ServerPlayer p : winners) {
            PlayerProfile prof = data.profile(p);
            prof.setDone(EntityKind.KEEPER, lvl);
            prof.addRelation(EntityKind.KEEPER, 5);
            prof.remember(EntityKind.KEEPER, "defeated_l" + lvl, sl.getGameTime(), p.blockPosition());
            removeTempEyes(p);
            Fx.say(p, EntityKind.KEEPER, "keeper.l" + lvl + ".defeat");
            giveRewards(p, lvl, prof);
        }
    }

    private void giveRewards(ServerPlayer p, int lvl, PlayerProfile prof) {
        switch (lvl) {
            case 1 -> {
                give(p, ModItems.PALE_FRAGMENT, 2);
                give(p, ModItems.PALE_BREAD, 2);
                give(p, ModItems.KEEPER_SIGIL, 1);
                Fx.hint(p, "reward.l1");
            }
            case 2 -> {
                give(p, ModItems.PALE_FRAGMENT, 3);
                give(p, ModItems.KEEPER_SIGIL, 1);
                Fx.hint(p, "reward.l2");
            }
            case 3 -> {
                give(p, ModItems.ELECTRIC_SCEPTER, 1);
                give(p, ModItems.KEEPER_SIGIL, 1);
                give(p, ModItems.PALE_FRAGMENT, 4);
                Fx.hint(p, "reward.l3");
            }
            case 4 -> {
                if (choiceKill) {
                    prof.flags.add("keeper_killed");
                    prof.addRelation(EntityKind.KEEPER, -30);
                    give(p, ModItems.LIGHTNING_BLADE, 1);
                    give(p, ModItems.PALE_FRAGMENT, 6);
                    Fx.hint(p, "reward.l4.kill");
                } else {
                    prof.flags.add("keeper_spared");
                    prof.addRelation(EntityKind.KEEPER, 20);
                    give(p, ModItems.RITUAL_EYE, 1);
                    give(p, ModItems.MOON_APPLE, 2);
                    Fx.hint(p, "reward.l4.spare");
                }
            }
            default -> {
                give(p, ModItems.EDEN_FRUIT, 1);
                give(p, ModItems.PALE_FRAGMENT, 8);
                give(p, ModItems.MOON_APPLE, 3);
                Fx.hint(p, "reward.l5");
            }
        }
    }

    private void give(ServerPlayer p, Supplier<? extends Item> item, int count) {
        giveOrDrop(p, new ItemStack(item.get(), count));
    }

    // ------------------------------------------------------------------ salvataggio
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("BossLevel", getBossLevel());
        tag.putInt("Contacts", contacts);
        tag.putInt("PearlHits", pearlHits);
        tag.putInt("Phase", phase);
        tag.putBoolean("Choice", choice);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("BossLevel")) {
            int saved = tag.getInt("BossLevel");
            float hp = getHealth();
            setBossLevel(saved);
            if (hp > 0.0F) setHealth(Math.min(hp, getMaxHealth()));
        }
        contacts = tag.getInt("Contacts");
        pearlHits = tag.getInt("PearlHits");
        phase = tag.getInt("Phase");
        choice = tag.getBoolean("Choice");
        if (choice) choiceTicks = 20 * 30;
    }
}
