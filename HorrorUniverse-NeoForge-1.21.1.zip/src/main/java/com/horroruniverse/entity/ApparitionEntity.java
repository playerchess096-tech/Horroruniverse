package com.horroruniverse.entity;

import com.horroruniverse.core.EntityKind;
import com.horroruniverse.registry.ModEntities;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Presenza autonoma delle sei entita' fuori dalle boss fight: figura immobile che osserva e poi svanisce.
 * Invulnerabile, non attacca e non blocca il passaggio. Il comportamento dipende dall'entita':
 *  - VANISH_ON_LOOK: svanisce se guardata abbastanza a lungo (Osservatore, Corrotto, Entity 404)
 *  - VANISH_ON_APPROACH: svanisce se il giocatore si avvicina (Custode, Uomo Magico)
 *  - GIFT_ON_APPROACH: lascia un piccolo regalo e se ne va (Steve)
 *  - TIMED: resta finche' non scade (esche del Custode livello 5: svaniscono se colpite)
 */
public class ApparitionEntity extends PathfinderMob {
    public enum Behavior { VANISH_ON_LOOK, VANISH_ON_APPROACH, GIFT_ON_APPROACH, TIMED }

    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(ApparitionEntity.class, EntityDataSerializers.INT);

    private Behavior behavior = Behavior.VANISH_ON_LOOK;
    private int life = 20 * 60;
    private int watched;
    private double vanishDistance = 10.0D;
    private boolean decoy;

    public ApparitionEntity(EntityType<? extends ApparitionEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D);
    }

    /** Crea un'apparizione. Restituisce null se non riesce. */
    public static ApparitionEntity spawn(ServerLevel sl, EntityKind kind, Vec3 pos, Behavior behavior,
                                         int lifeTicks, double vanishDistance, boolean decoy) {
        ApparitionEntity a = ModEntities.APPARITION.get().create(sl);
        if (a == null) return null;
        a.moveTo(pos.x, pos.y, pos.z, sl.getRandom().nextFloat() * 360.0F, 0.0F);
        a.setKind(kind);
        a.behavior = behavior;
        a.life = lifeTicks;
        a.vanishDistance = vanishDistance;
        a.decoy = decoy;
        a.setPersistenceRequired();
        sl.addFreshEntity(a);
        return a;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_KIND, EntityKind.OBSERVER.ordinal());
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 64.0F));
    }

    public EntityKind getKind() {
        return EntityKind.byIndex(this.entityData.get(DATA_KIND));
    }

    public void setKind(EntityKind kind) {
        this.entityData.set(DATA_KIND, kind.ordinal());
    }

    public boolean isDecoy() {
        return decoy;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;
        if (--life <= 0) {
            vanish(sl);
            return;
        }
        ambientParticles(sl);
        if (tickCount % 4 != 0) return;
        Player near = sl.getNearestPlayer(this, 80.0D);
        if (!(near instanceof ServerPlayer p)) {
            if (tickCount > 200) vanish(sl);
            return;
        }
        getLookControl().setLookAt(p, 40.0F, 40.0F);
        double dist = distanceTo(p);
        switch (behavior) {
            case VANISH_ON_LOOK -> {
                if (isLookedAt(p)) {
                    watched += 4;
                    if (watched >= 16) vanish(sl);
                } else {
                    watched = Math.max(0, watched - 2);
                }
                if (dist < vanishDistance * 0.4D) vanish(sl);
            }
            case VANISH_ON_APPROACH -> {
                if (dist < vanishDistance) vanish(sl);
            }
            case GIFT_ON_APPROACH -> {
                if (dist < 7.0D) {
                    dropGift(sl);
                    vanish(sl);
                }
            }
            case TIMED -> {}
        }
    }

    private boolean isLookedAt(ServerPlayer p) {
        Vec3 toMe = getEyePosition().subtract(p.getEyePosition()).normalize();
        return p.getViewVector(1.0F).dot(toMe) > 0.96D && p.hasLineOfSight(this);
    }

    private void ambientParticles(ServerLevel sl) {
        if (tickCount % 10 != 0) return;
        ParticleOptions particle;
        switch (getKind()) {
            case KEEPER -> particle = ParticleTypes.END_ROD;
            case CORRUPTED -> particle = ParticleTypes.SQUID_INK;
            case ENTITY_404 -> particle = ParticleTypes.HAPPY_VILLAGER;
            case MAGE -> particle = ParticleTypes.ENCHANT;
            case STEVE -> { return; }
            default -> { return; }
        }
        sl.sendParticles(particle, getX(), getY() + 1.0D, getZ(), 2, 0.3D, 0.6D, 0.3D, 0.01D);
    }

    private void dropGift(ServerLevel sl) {
        ItemStack gift = switch (random.nextInt(4)) {
            case 0 -> new ItemStack(Items.BREAD, 3);
            case 1 -> new ItemStack(Items.TORCH, 6);
            case 2 -> new ItemStack(Items.COOKED_BEEF, 2);
            default -> new ItemStack(Items.ARROW, 8);
        };
        sl.addFreshEntity(new ItemEntity(sl, getX(), getY() + 0.5D, getZ(), gift));
    }

    public void vanish(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0D, getZ(), 14, 0.3D, 0.7D, 0.3D, 0.02D);
        SoundEvent s = switch (getKind()) {
            case KEEPER, MAGE -> SoundEvents.ENDERMAN_TELEPORT;
            case ENTITY_404 -> SoundEvents.GLASS_BREAK;
            default -> SoundEvents.AMETHYST_BLOCK_CHIME;
        };
        sl.playSound(null, getX(), getY(), getZ(), s, SoundSource.AMBIENT, 0.4F, 0.6F);
        discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        if (!level().isClientSide && decoy && source.getEntity() instanceof Player && level() instanceof ServerLevel sl) {
            vanish(sl);
        }
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Kind", getKind().ordinal());
        tag.putInt("Life", life);
        tag.putBoolean("Decoy", decoy);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_KIND, Mth.clamp(tag.getInt("Kind"), 0, EntityKind.values().length - 1));
        life = tag.contains("Life") ? tag.getInt("Life") : 20 * 30;
        decoy = tag.getBoolean("Decoy");
    }
}
