package com.horroruniverse.client;

import com.horroruniverse.HorrorUniverse;
import com.horroruniverse.entity.ApparitionEntity;
import com.horroruniverse.entity.KeeperMinion;
import com.horroruniverse.entity.WhiteEyedKeeper;
import com.horroruniverse.registry.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

import java.util.Locale;

/** Registrazione dei renderer (solo client). */
@EventBusSubscriber(modid = HorrorUniverse.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(HorrorUniverse.MODID, "textures/entity/" + name + ".png");
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.KEEPER.get(),
                ctx -> new PlayerLikeRenderer<WhiteEyedKeeper>(ctx, k -> tex("keeper_l" + k.getBossLevel())));
        event.registerEntityRenderer(ModEntities.KEEPER_MINION.get(),
                ctx -> new PlayerLikeRenderer<KeeperMinion>(ctx, m -> tex("minion_" + m.getKind().name().toLowerCase(Locale.ROOT))));
        event.registerEntityRenderer(ModEntities.APPARITION.get(),
                ctx -> new PlayerLikeRenderer<ApparitionEntity>(ctx, a -> tex("apparition_" + a.getKind().id)));
        event.registerEntityRenderer(ModEntities.WHITE_EYED_ZOMBIE.get(), WhiteEyedZombieRenderer::new);
        event.registerEntityRenderer(ModEntities.RITUAL_PEARL.get(), ThrownItemRenderer::new);
    }
}
