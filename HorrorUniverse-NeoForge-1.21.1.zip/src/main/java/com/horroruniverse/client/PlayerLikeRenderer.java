package com.horroruniverse.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

import java.util.function.Function;

/** Renderer umanoide con la geometria della skin del giocatore e una texture scelta dall'entita'. */
public class PlayerLikeRenderer<T extends Mob> extends HumanoidMobRenderer<T, HumanoidModel<T>> {
    private final Function<T, ResourceLocation> texture;

    public PlayerLikeRenderer(EntityRendererProvider.Context context, Function<T, ResourceLocation> texture) {
        super(context, new HumanoidModel<T>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        this.addLayer(new HumanoidArmorLayer<T, HumanoidModel<T>, HumanoidModel<T>>(this,
                new HumanoidModel<T>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<T>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                context.getModelManager()));
        this.texture = texture;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture.apply(entity);
    }
}
