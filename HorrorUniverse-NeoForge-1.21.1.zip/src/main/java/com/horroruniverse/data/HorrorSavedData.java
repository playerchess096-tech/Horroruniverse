package com.horroruniverse.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Progressione, scelte e memoria salvate nel mondo (mai file esterni, mai cancellazioni). */
public class HorrorSavedData extends SavedData {
    private static final String NAME = "horroruniverse_progress";
    private final Map<UUID, PlayerProfile> profiles = new HashMap<>();

    public HorrorSavedData() {}

    public static HorrorSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<HorrorSavedData>(HorrorSavedData::new, HorrorSavedData::load, null), NAME);
    }

    public PlayerProfile profile(UUID id) {
        setDirty();
        return profiles.computeIfAbsent(id, k -> new PlayerProfile());
    }

    public PlayerProfile profile(ServerPlayer player) {
        return profile(player.getUUID());
    }

    public static HorrorSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        HorrorSavedData data = new HorrorSavedData();
        CompoundTag players = tag.getCompound("players");
        for (String key : players.getAllKeys()) {
            try {
                data.profiles.put(UUID.fromString(key), PlayerProfile.load(players.getCompound(key)));
            } catch (IllegalArgumentException ignored) {
                // chiave non valida: la salto senza toccare gli altri dati
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        CompoundTag players = new CompoundTag();
        for (Map.Entry<UUID, PlayerProfile> e : profiles.entrySet()) {
            players.put(e.getKey().toString(), e.getValue().save());
        }
        tag.put("players", players);
        return tag;
    }
}
