package com.horroruniverse.data;

import com.horroruniverse.core.EntityKind;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Cio' che le entita' "sanno" di un giocatore: solo informazioni registrate legittimamente (Parte 1.2 / 12.1).
 * La memoria e' limitata (MAX_MEMORY voci) e significativa, non un log di ogni movimento.
 */
public class PlayerProfile {
    public static final int MAX_MEMORY = 48;

    public final int[] levelDone = new int[EntityKind.values().length];
    public final int[] relation = new int[EntityKind.values().length];
    public final Set<String> flags = new HashSet<>();
    public final Map<String, Long> cooldowns = new HashMap<>();
    public final ArrayDeque<MemoryEntry> memory = new ArrayDeque<>();
    public long nextEventTick;
    public long lastSeenTick;
    public long playedTicks;
    public long minedTicks;
    public int deaths;
    public int diamonds;
    public boolean jumpscares = true;
    public boolean invasive = true;

    public record MemoryEntry(String kind, String type, long tick, int x, int y, int z) {}

    public int done(EntityKind k) {
        return levelDone[k.ordinal()];
    }

    public void setDone(EntityKind k, int level) {
        if (level > levelDone[k.ordinal()]) levelDone[k.ordinal()] = level;
    }

    public void addRelation(EntityKind k, int delta) {
        relation[k.ordinal()] = Math.max(-100, Math.min(100, relation[k.ordinal()] + delta));
    }

    public void remember(EntityKind k, String type, long tick, BlockPos pos) {
        while (memory.size() >= MAX_MEMORY) memory.removeFirst();
        memory.addLast(new MemoryEntry(k.id, type, tick, pos.getX(), pos.getY(), pos.getZ()));
    }

    public int countRecent(EntityKind k, String type, long sinceTick) {
        int n = 0;
        for (MemoryEntry m : memory) {
            if (m.kind().equals(k.id) && m.type().equals(type) && m.tick() >= sinceTick) n++;
        }
        return n;
    }

    public boolean cooledDown(String id, long now) {
        Long until = cooldowns.get(id);
        return until == null || now >= until;
    }

    public void setCooldown(String id, long until) {
        cooldowns.put(id, until);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putIntArray("done", levelDone.clone());
        t.putIntArray("rel", relation.clone());
        ListTag fl = new ListTag();
        for (String s : flags) fl.add(StringTag.valueOf(s));
        t.put("flags", fl);
        CompoundTag cd = new CompoundTag();
        for (Map.Entry<String, Long> e : cooldowns.entrySet()) cd.putLong(e.getKey(), e.getValue());
        t.put("cd", cd);
        ListTag mem = new ListTag();
        for (MemoryEntry m : memory) {
            CompoundTag c = new CompoundTag();
            c.putString("k", m.kind());
            c.putString("t", m.type());
            c.putLong("tick", m.tick());
            c.putInt("x", m.x());
            c.putInt("y", m.y());
            c.putInt("z", m.z());
            mem.add(c);
        }
        t.put("mem", mem);
        t.putLong("next", nextEventTick);
        t.putLong("seen", lastSeenTick);
        t.putLong("played", playedTicks);
        t.putLong("mined", minedTicks);
        t.putInt("deaths", deaths);
        t.putInt("diamonds", diamonds);
        t.putBoolean("jumpscares", jumpscares);
        t.putBoolean("invasive", invasive);
        return t;
    }

    public static PlayerProfile load(CompoundTag t) {
        PlayerProfile p = new PlayerProfile();
        int[] d = t.getIntArray("done");
        System.arraycopy(d, 0, p.levelDone, 0, Math.min(d.length, p.levelDone.length));
        int[] r = t.getIntArray("rel");
        System.arraycopy(r, 0, p.relation, 0, Math.min(r.length, p.relation.length));
        ListTag fl = t.getList("flags", Tag.TAG_STRING);
        for (int i = 0; i < fl.size(); i++) p.flags.add(fl.getString(i));
        CompoundTag cd = t.getCompound("cd");
        for (String key : cd.getAllKeys()) p.cooldowns.put(key, cd.getLong(key));
        ListTag mem = t.getList("mem", Tag.TAG_COMPOUND);
        for (int i = 0; i < mem.size(); i++) {
            CompoundTag c = mem.getCompound(i);
            p.memory.addLast(new MemoryEntry(c.getString("k"), c.getString("t"), c.getLong("tick"),
                    c.getInt("x"), c.getInt("y"), c.getInt("z")));
        }
        p.nextEventTick = t.getLong("next");
        p.lastSeenTick = t.getLong("seen");
        p.playedTicks = t.getLong("played");
        p.minedTicks = t.getLong("mined");
        p.deaths = t.getInt("deaths");
        p.diamonds = t.getInt("diamonds");
        p.jumpscares = !t.contains("jumpscares") || t.getBoolean("jumpscares");
        p.invasive = !t.contains("invasive") || t.getBoolean("invasive");
        return p;
    }
}
