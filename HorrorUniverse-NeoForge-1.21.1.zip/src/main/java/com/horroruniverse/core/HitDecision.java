package com.horroruniverse.core;

/** Esito della valutazione di un colpo: accettato (con danno) oppure respinto (con motivo). */
public record HitDecision(boolean accepted, float damage, boolean counts, String reason) {

    public static HitDecision accept(float damage, boolean counts) {
        return new HitDecision(true, damage, counts, "ok");
    }

    public static HitDecision deflect(String reason) {
        return new HitDecision(false, 0.0F, false, reason);
    }
}
