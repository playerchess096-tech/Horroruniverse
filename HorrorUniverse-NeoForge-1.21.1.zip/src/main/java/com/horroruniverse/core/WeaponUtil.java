package com.horroruniverse.core;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;

public final class WeaponUtil {
    private WeaponUtil() {}

    /**
     * Attacco "da scheda" dell'arma: 1.0 (base del giocatore) + modificatori ADD_VALUE su ATTACK_DAMAGE dell'oggetto.
     * Non conta pozioni (Forza), incantesimi, critici o ricarica: la soglia riguarda l'arma, non il singolo colpo.
     * Spada di diamante = 7, spada di netherite = 8.
     */
    public static double weaponAttack(ItemStack stack) {
        if (stack.isEmpty()) return 1.0D;
        ItemAttributeModifiers mods = stack.getOrDefault(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers.EMPTY);
        double bonus = 0.0D;
        for (ItemAttributeModifiers.Entry e : mods.modifiers()) {
            if (e.attribute().equals(Attributes.ATTACK_DAMAGE)
                    && e.modifier().operation() == AttributeModifier.Operation.ADD_VALUE) {
                bonus += e.modifier().amount();
            }
        }
        return 1.0D + bonus;
    }

    public static SpecialWeapon classify(ItemStack stack) {
        if (!stack.isEmpty() && stack.getItem() instanceof SpecialWeaponItem sw) {
            return sw.specialWeapon();
        }
        return SpecialWeapon.NONE;
    }
}
