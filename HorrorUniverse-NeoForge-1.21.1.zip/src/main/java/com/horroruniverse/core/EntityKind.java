package com.horroruniverse.core;

/** Le sei entita' del progetto. minDay = giorni di gioco (24000 tick) prima che compaiano gli eventi ambientali. */
public enum EntityKind {
    KEEPER("keeper", 1),
    CORRUPTED("corrupted", 2),
    ENTITY_404("entity404", 5),
    MAGE("mage", 3),
    STEVE("steve", 3),
    OBSERVER("observer", 0);

    public final String id;
    public final int minDay;

    EntityKind(String id, int minDay) {
        this.id = id;
        this.minDay = minDay;
    }

    public static EntityKind byIndex(int i) {
        EntityKind[] v = values();
        return v[Math.floorMod(i, v.length)];
    }

    public static EntityKind byId(String id) {
        for (EntityKind k : values()) {
            if (k.id.equals(id)) return k;
        }
        return null;
    }
}
