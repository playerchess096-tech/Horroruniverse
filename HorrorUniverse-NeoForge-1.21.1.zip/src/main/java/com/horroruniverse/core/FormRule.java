package com.horroruniverse.core;

/**
 * Regola di vulnerabilita' di una forma di boss.
 * hitsL3 / hitsL6 = colpi validi necessari con l'arma speciale del livello 3 / 6 (0 = non applicabile).
 * proposed = valore NON presente nel prompt, proposto per colmare un vuoto (segnalato in docs/ANALISI.md).
 */
public record FormRule(String id, EntityKind kind, int level, VulnType type, int hitsL3, int hitsL6,
                       double minAttack, boolean inclusive, boolean proposed, String note) {

    public boolean passesThreshold(double attack) {
        return inclusive ? attack >= minAttack - 1.0E-6D : attack > minAttack + 1.0E-6D;
    }
}
