package com.horroruniverse.core;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/** Ricerca di punti dove una creatura puo' stare in piedi, senza forzare il caricamento di chunk. */
public final class Spots {
    private Spots() {}

    /** Punto in piedi a distanza [minR, maxR] dal centro (stessa fascia verticale +-vertical), oppure null. */
    public static Vec3 find(ServerLevel level, Vec3 center, double minR, double maxR, int tries, int vertical) {
        RandomSource rnd = level.getRandom();
        int cy = Mth.floor(center.y);
        for (int i = 0; i < tries; i++) {
            double ang = rnd.nextDouble() * Math.PI * 2.0D;
            double r = minR + rnd.nextDouble() * Math.max(0.0D, maxR - minR);
            int x = Mth.floor(center.x + Math.cos(ang) * r);
            int z = Mth.floor(center.z + Math.sin(ang) * r);
            if (!level.hasChunkAt(new BlockPos(x, cy, z))) continue;
            for (int dy = vertical; dy >= -vertical; dy--) {
                BlockPos pos = new BlockPos(x, cy + dy, z);
                if (standable(level, pos)) return Vec3.atBottomCenterOf(pos);
            }
        }
        return null;
    }

    public static boolean standable(ServerLevel level, BlockPos pos) {
        BlockPos below = pos.below();
        BlockPos above = pos.above();
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                && level.getBlockState(above).getCollisionShape(level, above).isEmpty()
                && level.getFluidState(pos).isEmpty()
                && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    /** Punto dietro al giocatore (rispetto a dove guarda), a 'dist' blocchi. */
    public static Vec3 behind(net.minecraft.world.entity.player.Player p, double dist) {
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0D, look.z);
        if (flat.lengthSqr() < 1.0E-4D) flat = new Vec3(0.0D, 0.0D, 1.0D);
        flat = flat.normalize();
        return p.position().subtract(flat.scale(dist));
    }
}
