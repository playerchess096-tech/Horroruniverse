package com.horroruniverse.core;

/** Armi speciali distinte dalle armi normali (Parte 9.5). */
public enum SpecialWeapon {
    NONE,
    PLAGUE_BLADE,   // "arma del livello 3 di Entity 404"
    METEOR_BLADE,   // "arma del livello 6 di Entity 404"
    RITUAL_PEARL    // perla valida per il Custode livello 5
}
