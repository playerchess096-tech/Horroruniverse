package com.horroruniverse.core;

import com.horroruniverse.config.HorrorConfig;
import com.horroruniverse.registry.ModEffects;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

/**
 * Applicazione centralizzata degli effetti negativi della mod.
 * Frutto dell'Eden (effetto "Protezione dell'Eden") blocca SOLO questi effetti quando li infligge la mod:
 * Scossa, Oscurita', Nausea, Lentezza, Debolezza, Cecita'. Non blocca danni, fulmini, cadute ne' attacchi diretti.
 */
public final class HorrorEffects {
    private HorrorEffects() {}

    public static boolean isBlockable(Holder<MobEffect> effect) {
        MobEffect v = effect.value();
        return v == ModEffects.SHOCK.get()
                || v == MobEffects.DARKNESS.value()
                || v == MobEffects.CONFUSION.value()
                || v == MobEffects.MOVEMENT_SLOWDOWN.value()
                || v == MobEffects.WEAKNESS.value()
                || v == MobEffects.BLINDNESS.value();
    }

    public static boolean apply(LivingEntity target, Holder<MobEffect> effect, int ticks, int amplifier) {
        if (isBlockable(effect) && target.hasEffect(ModEffects.EDEN_WARD)) return false;
        int t = Math.max(1, (int) Math.round(ticks * HorrorConfig.EFFECT_DURATION.get()));
        return target.addEffect(new MobEffectInstance(effect, t, amplifier));
    }

    /** Cooldown di abilita' scalato dalla configurazione. */
    public static int cd(int ticks) {
        return Math.max(1, (int) Math.round(ticks * HorrorConfig.COOLDOWN.get()));
    }
}
