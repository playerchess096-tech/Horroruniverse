package com.horroruniverse.core;

/** Stati dell'AI (Parte 12.2). Non tutte le entita' li usano tutti. */
public enum AiState {
    DORMANT, WATCHING, EXPLORING, CURIOUS, HOSTILE, FIGHTING, FLEEING, PREPARING,
    VULNERABLE, DEFEATED, TRUCE, ALLY, FINAL_PHASE
}
