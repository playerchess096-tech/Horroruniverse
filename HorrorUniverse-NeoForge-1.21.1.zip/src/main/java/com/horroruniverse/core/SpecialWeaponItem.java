package com.horroruniverse.core;

public interface SpecialWeaponItem {
    SpecialWeapon specialWeapon();
}
