package com.horroruniverse.core;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** Effetti e messaggi inviati a UN solo giocatore (cosi' gli scherzi horror non disturbano gli altri). */
public final class Fx {
    private Fx() {}

    public static void sound(ServerPlayer p, SoundEvent sound, Vec3 at, float volume, float pitch) {
        p.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound),
                SoundSource.AMBIENT, at.x, at.y, at.z, volume, pitch, p.level().getRandom().nextLong()));
    }

    public static void particles(ServerPlayer p, ParticleOptions options, Vec3 at, int count,
                                 double dx, double dy, double dz, double speed) {
        p.serverLevel().sendParticles(p, options, true, at.x, at.y, at.z, count, dx, dy, dz, speed);
    }

    public static void title(ServerPlayer p, Component title, Component subtitle, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    public static void actionBar(ServerPlayer p, Component c) {
        p.displayClientMessage(c, true);
    }

    /** Messaggio breve di sistema (indizi, avvisi), in grigio corsivo. */
    public static void hint(ServerPlayer p, String key, Object... args) {
        p.sendSystemMessage(Component.translatable("horroruniverse.hint." + key, args)
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
    }

    /** Battuta di un'entita': <Nome> testo. Le chiavi stanno nei file lang. */
    public static void say(ServerPlayer p, EntityKind who, String key, Object... args) {
        MutableComponent name = Component.translatable("horroruniverse.name." + who.id).withStyle(ChatFormatting.WHITE);
        MutableComponent msg = Component.literal("<").append(name).append("> ")
                .append(Component.translatable("horroruniverse.line." + key, args).withStyle(ChatFormatting.ITALIC, ChatFormatting.GRAY));
        p.sendSystemMessage(msg);
    }

    /** Titolo + sottotitolo inquietanti (conta come jumpscare soltanto se lo chiede il chiamante). */
    public static void creepyTitle(ServerPlayer p, String key) {
        title(p, Component.empty(), Component.translatable("horroruniverse.sub." + key).withStyle(ChatFormatting.DARK_RED), 10, 50, 20);
    }
}
