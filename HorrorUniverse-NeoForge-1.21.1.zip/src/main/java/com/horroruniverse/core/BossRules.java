package com.horroruniverse.core;

import com.horroruniverse.config.HorrorConfig;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Tabella centrale delle vulnerabilita' (Parte 9). Tutti i numeri del prompt sono qui, in un posto solo.
 * Le righe con proposed=true colmano vuoti del prompt e sono elencate in docs/ANALISI.md.
 */
public final class BossRules {
    private static final Map<String, FormRule> RULES = new LinkedHashMap<>();

    private BossRules() {}

    private static void add(String id, EntityKind k, int lvl, VulnType t, int h3, int h6,
                            double min, boolean incl, boolean proposed, String note) {
        RULES.put(id, new FormRule(id, k, lvl, t, h3, h6, min, incl, proposed, note));
    }

    static {
        // --- Custode ---
        add("keeper_l1", EntityKind.KEEPER, 1, VulnType.NORMAL, 1, 1, 0, false, false, "Guardiano: 3 ondate di zombie");
        add("keeper_l2", EntityKind.KEEPER, 2, VulnType.INVULNERABLE_SPECIAL, 0, 0, 0, false, false, "Prova del Contatto: 3 contatti validi, non attaccabile");
        add("keeper_l2_zombie", EntityKind.KEEPER, 2, VulnType.NORMAL, 2, 1, 0, false, false, "Zombie dagli Occhi Bianchi");
        add("keeper_l3", EntityKind.KEEPER, 3, VulnType.NORMAL, 2, 1, 0, false, false, "Scettro Elettrico");
        add("keeper_l4", EntityKind.KEEPER, 4, VulnType.THRESHOLD, 3, 1, 7.0D, false, false, "Custode Supremo: attacco > 7 (netherite = 8)");
        add("keeper_l5", EntityKind.KEEPER, 5, VulnType.RITUAL, 0, 0, 0, false, false, "Rituale Proibito: 10 Perle del Rituale in finestra valida");
        // --- Corrotto ---
        add("corrupted_l1", EntityKind.CORRUPTED, 1, VulnType.INVULNERABLE_SPECIAL, 2, 1, 0, false, false, "Armi normali respinte; armi speciali ammesse (vedi C2)");
        add("corrupted_l2", EntityKind.CORRUPTED, 2, VulnType.INVULNERABLE_SPECIAL, 2, 1, 0, false, false, "Armi normali respinte; armi speciali ammesse (vedi C2)");
        add("corrupted_l3", EntityKind.CORRUPTED, 3, VulnType.CONDITIONAL, 3, 1, 0, false, false, "Serve l'artefatto anti-oscurita'");
        add("corrupted_l4", EntityKind.CORRUPTED, 4, VulnType.TEMPORARY, 1, 1, 0, false, false, "Finestra di vulnerabilita' obbligatoria");
        add("corrupted_l5", EntityKind.CORRUPTED, 5, VulnType.CONDITIONAL, 4, 2, 0, false, false, "Artefatto anti-oscurita' usato 2 volte");
        // --- Entity 404 ---
        add("entity404_l3", EntityKind.ENTITY_404, 3, VulnType.SPECIFIC, 0, 0, 0, false, false, "Dipende dall'arma specifica creata dal giocatore");
        add("entity404_l4", EntityKind.ENTITY_404, 4, VulnType.TEMPORARY, 3, 0, 0, false, true, "3 colpi con l'arma specifica (par. 4.6); L6 non specificato");
        add("entity404_l5", EntityKind.ENTITY_404, 5, VulnType.CONDITIONAL, 6, 3, 0, false, true, "PROPOSTA (vedi C3): non presente nel prompt");
        add("entity404_l6", EntityKind.ENTITY_404, 6, VulnType.CONDITIONAL, 12, 6, 0, false, true, "PROPOSTA (vedi C3): tra clone (4/2) e livello 7 (20/10)");
        add("entity404_l7", EntityKind.ENTITY_404, 7, VulnType.CONDITIONAL, 20, 10, 0, false, false, "Statue del Destino + barriera + timer");
        add("entity404_clone", EntityKind.ENTITY_404, 8, VulnType.NORMAL, 4, 2, 0, false, false, "Clone vendicativo (livello bonus)");
        // --- Uomo Magico ---
        add("mage_l1", EntityKind.MAGE, 1, VulnType.NORMAL, 0, 0, 0, false, false, "Spada di ferro o armi valide");
        add("mage_l3", EntityKind.MAGE, 3, VulnType.CONDITIONAL, 0, 0, 0, false, false, "3 rune attive = molto difficile da danneggiare");
        add("mage_l4", EntityKind.MAGE, 4, VulnType.THRESHOLD, 0, 0, 7.0D, true, false, "Spada di diamante (attacco >= 7) dopo aver esaurito l'energia magica");
        add("mage_l5", EntityKind.MAGE, 5, VulnType.CONDITIONAL, 0, 0, 0, false, false, "5 rune antiche + bastone");
        // --- Steve ---
        add("steve_l5", EntityKind.STEVE, 5, VulnType.NORMAL, 0, 0, 0, false, false, "Nessuna immunita': preparazione e strategia");
    }

    public static FormRule get(String id) {
        return RULES.get(id);
    }

    public static List<FormRule> all() {
        return Collections.unmodifiableList(new ArrayList<>(RULES.values()));
    }

    /** Valuta un colpo contro una forma di boss. Condizioni di registrazione: Parte 9.5. */
    public static HitDecision evaluate(FormRule rule, ItemStack weapon, float incoming, float maxHealth,
                                       boolean windowOpen, boolean conditionMet) {
        SpecialWeapon sw = WeaponUtil.classify(weapon);
        boolean gate = switch (rule.type()) {
            case TEMPORARY -> windowOpen;
            case CONDITIONAL -> conditionMet;
            default -> true;
        };
        int hits = switch (sw) {
            case PLAGUE_BLADE -> rule.hitsL3();
            case METEOR_BLADE -> rule.hitsL6();
            default -> 0;
        };
        if (hits > 0) {
            if (!gate) return HitDecision.deflect("not_vulnerable");
            // danno = salute massima / colpi richiesti: esattamente 'hits' colpi validi uccidono
            return HitDecision.accept(maxHealth / (float) hits + 0.01F, true);
        }
        return switch (rule.type()) {
            case NORMAL -> HitDecision.accept(incoming, true);
            case THRESHOLD -> {
                boolean ok = !HorrorConfig.WEAPON_THRESHOLDS.get() || rule.passesThreshold(WeaponUtil.weaponAttack(weapon));
                if (!ok) yield HitDecision.deflect("below_threshold");
                if (!gate) yield HitDecision.deflect("not_vulnerable");
                yield HitDecision.accept(incoming, true);
            }
            case TEMPORARY, CONDITIONAL -> gate ? HitDecision.accept(incoming, true) : HitDecision.deflect("not_vulnerable");
            default -> HitDecision.deflect("immune");
        };
    }
}
