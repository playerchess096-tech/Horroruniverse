package com.horroruniverse.core;

/** Le otto categorie di vulnerabilita' (Parte 9.3). */
public enum VulnType {
    NORMAL,                // 1. subisce danni dalle armi consentite
    THRESHOLD,             // 2. serve un attacco sufficiente
    TEMPORARY,             // 3. solo in determinate fasi / finestre
    SPECIFIC,              // 4. serve un'arma o un oggetto specifico
    INVULNERABLE_SPECIAL,  // 5. ignora le armi normali
    RITUAL,                // 6. attaccabile solo dopo una meccanica narrativa
    PROJECTILE,            // 7. solo proiettili/oggetti particolari
    CONDITIONAL            // 8. richiede rune, generatori, scudi o servitori neutralizzati
}
