package com.horroruniverse.registry;

import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;

import java.util.function.Supplier;

/** Materiali delle armi della mod. Attacco da scheda = 1 (giocatore) + 3 (spada) + bonus. */
public enum HorrorTier implements Tier {
    /** Lama della Piaga: attacco 8 (come la netherite). */
    PLAGUE(1800, 8.0F, 4.0F, 18, () -> Ingredient.of(net.minecraft.world.item.Items.NETHERITE_INGOT)),
    /** Spada Meteorica: attacco 10. */
    METEOR(2800, 9.0F, 6.0F, 22, () -> Ingredient.of(net.minecraft.world.item.Items.NETHER_STAR)),
    /** Lama del Fulmine: attacco 7 (come il diamante). */
    LIGHTNING(1500, 8.0F, 3.0F, 20, () -> Ingredient.of(net.minecraft.world.item.Items.LIGHTNING_ROD));

    private final int uses;
    private final float speed;
    private final float damageBonus;
    private final int enchantability;
    private final Supplier<Ingredient> repair;

    HorrorTier(int uses, float speed, float damageBonus, int enchantability, Supplier<Ingredient> repair) {
        this.uses = uses;
        this.speed = speed;
        this.damageBonus = damageBonus;
        this.enchantability = enchantability;
        this.repair = repair;
    }

    @Override
    public int getUses() {
        return uses;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public float getAttackDamageBonus() {
        return damageBonus;
    }

    @Override
    public TagKey<Block> getIncorrectBlocksForDrops() {
        return BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return repair.get();
    }
}
