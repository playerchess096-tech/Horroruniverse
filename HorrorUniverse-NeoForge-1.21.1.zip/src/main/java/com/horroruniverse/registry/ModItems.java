package com.horroruniverse.registry;

import com.horroruniverse.HorrorUniverse;
import com.horroruniverse.core.SpecialWeapon;
import com.horroruniverse.item.EdenFruitItem;
import com.horroruniverse.item.ElectricScepterItem;
import com.horroruniverse.item.KeeperSigilItem;
import com.horroruniverse.item.LightningBladeItem;
import com.horroruniverse.item.RitualEyeItem;
import com.horroruniverse.item.RitualPearlItem;
import com.horroruniverse.item.SpecialSwordItem;
import com.horroruniverse.item.TruthLensItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(HorrorUniverse.MODID);

    // --- materiali e oggetti di progressione ---
    public static final DeferredHolder<Item, Item> PALE_FRAGMENT = ITEMS.register("pale_fragment",
            () -> new Item(new Item.Properties()));
    public static final DeferredHolder<Item, Item> KEEPER_SIGIL = ITEMS.register("keeper_sigil",
            () -> new KeeperSigilItem(new Item.Properties().stacksTo(8).rarity(Rarity.UNCOMMON)));
    public static final DeferredHolder<Item, Item> RITUAL_EYE = ITEMS.register("ritual_eye",
            () -> new RitualEyeItem(new Item.Properties().stacksTo(4).rarity(Rarity.RARE)));
    public static final DeferredHolder<Item, Item> RITUAL_PEARL = ITEMS.register("ritual_pearl",
            () -> new RitualPearlItem(new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final DeferredHolder<Item, Item> ELECTRIC_SCEPTER = ITEMS.register("electric_scepter",
            () -> new ElectricScepterItem(new Item.Properties().stacksTo(1).durability(120).rarity(Rarity.RARE)));
    public static final DeferredHolder<Item, Item> TRUTH_LENS = ITEMS.register("truth_lens",
            () -> new TruthLensItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    // --- Frutto dell'Eden: protezione dagli effetti negativi della mod, 5 minuti, cooldown 30 s ---
    public static final DeferredHolder<Item, Item> EDEN_FRUIT = ITEMS.register("eden_fruit",
            () -> new EdenFruitItem(new Item.Properties().stacksTo(4).rarity(Rarity.EPIC).food(
                    new FoodProperties.Builder().nutrition(10).saturationModifier(1.2F).alwaysEdible()
                            .effect(() -> new MobEffectInstance(ModEffects.EDEN_WARD, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 1), 1.0F)
                            .build())));

    // --- armi: le due armi speciali di Entity 404 (provvisorie finche' non c'e' il modulo 404) + extra ---
    public static final DeferredHolder<Item, Item> PLAGUE_BLADE = ITEMS.register("plague_blade",
            () -> new SpecialSwordItem(HorrorTier.PLAGUE, new Item.Properties().rarity(Rarity.EPIC).fireResistant()
                    .attributes(SwordItem.createAttributes(HorrorTier.PLAGUE, 3, -2.4F)), SpecialWeapon.PLAGUE_BLADE));
    public static final DeferredHolder<Item, Item> METEOR_BLADE = ITEMS.register("meteor_blade",
            () -> new SpecialSwordItem(HorrorTier.METEOR, new Item.Properties().rarity(Rarity.EPIC).fireResistant()
                    .attributes(SwordItem.createAttributes(HorrorTier.METEOR, 3, -2.4F)), SpecialWeapon.METEOR_BLADE));
    public static final DeferredHolder<Item, Item> LIGHTNING_BLADE = ITEMS.register("lightning_blade",
            () -> new LightningBladeItem(HorrorTier.LIGHTNING, new Item.Properties().rarity(Rarity.RARE)
                    .attributes(SwordItem.createAttributes(HorrorTier.LIGHTNING, 3, -2.4F))));

    // --- cibi extra ---
    public static final DeferredHolder<Item, Item> PALE_BREAD = ITEMS.register("pale_bread",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(7).saturationModifier(0.8F)
                    .effect(() -> new MobEffectInstance(MobEffects.NIGHT_VISION, 600, 0), 1.0F).build())));
    public static final DeferredHolder<Item, Item> MOON_APPLE = ITEMS.register("moon_apple",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON).food(new FoodProperties.Builder().nutrition(4)
                    .saturationModifier(1.0F).alwaysEdible()
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 1200, 0), 1.0F).build())));
    public static final DeferredHolder<Item, Item> RUNE_COOKIE = ITEMS.register("rune_cookie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.4F)
                    .fast().effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 600, 0), 1.0F).build())));

    private ModItems() {}
}
