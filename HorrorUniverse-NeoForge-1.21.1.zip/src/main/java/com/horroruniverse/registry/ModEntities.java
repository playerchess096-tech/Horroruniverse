package com.horroruniverse.registry;

import com.horroruniverse.HorrorUniverse;
import com.horroruniverse.entity.ApparitionEntity;
import com.horroruniverse.entity.KeeperMinion;
import com.horroruniverse.entity.RitualPearlEntity;
import com.horroruniverse.entity.WhiteEyedKeeper;
import com.horroruniverse.entity.WhiteEyedZombie;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, HorrorUniverse.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<WhiteEyedKeeper>> KEEPER = ENTITY_TYPES.register(
            "white_eyed_keeper", () -> EntityType.Builder.<WhiteEyedKeeper>of(WhiteEyedKeeper::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).fireImmune().build("white_eyed_keeper"));

    public static final DeferredHolder<EntityType<?>, EntityType<KeeperMinion>> KEEPER_MINION = ENTITY_TYPES.register(
            "keeper_minion", () -> EntityType.Builder.<KeeperMinion>of(KeeperMinion::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).build("keeper_minion"));

    public static final DeferredHolder<EntityType<?>, EntityType<WhiteEyedZombie>> WHITE_EYED_ZOMBIE = ENTITY_TYPES.register(
            "white_eyed_zombie", () -> EntityType.Builder.<WhiteEyedZombie>of(WhiteEyedZombie::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).fireImmune().build("white_eyed_zombie"));

    public static final DeferredHolder<EntityType<?>, EntityType<ApparitionEntity>> APPARITION = ENTITY_TYPES.register(
            "apparition", () -> EntityType.Builder.<ApparitionEntity>of(ApparitionEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).fireImmune().build("apparition"));

    public static final DeferredHolder<EntityType<?>, EntityType<RitualPearlEntity>> RITUAL_PEARL = ENTITY_TYPES.register(
            "ritual_pearl", () -> EntityType.Builder.<RitualPearlEntity>of(RitualPearlEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(10).build("ritual_pearl"));

    private ModEntities() {}

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(KEEPER.get(), WhiteEyedKeeper.createAttributes().build());
        event.put(KEEPER_MINION.get(), KeeperMinion.createAttributes().build());
        event.put(WHITE_EYED_ZOMBIE.get(), WhiteEyedZombie.createAttributes().build());
        event.put(APPARITION.get(), ApparitionEntity.createAttributes().build());
    }
}
