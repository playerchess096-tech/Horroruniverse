package com.horroruniverse.registry;

import com.horroruniverse.HorrorUniverse;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(Registries.MOB_EFFECT, HorrorUniverse.MODID);

    /** Scossa: piccoli danni elettrici periodici (mai letali da soli). */
    public static final DeferredHolder<MobEffect, MobEffect> SHOCK = EFFECTS.register("shock", () -> new ShockEffect());
    /** Protezione dell'Eden: blocca gli effetti negativi della mod (vedi HorrorEffects). */
    public static final DeferredHolder<MobEffect, MobEffect> EDEN_WARD = EFFECTS.register("eden_ward",
            () -> new BasicEffect(MobEffectCategory.BENEFICIAL, 0xF2E08A));

    private ModEffects() {}

    public static class BasicEffect extends MobEffect {
        public BasicEffect(MobEffectCategory category, int color) {
            super(category, color);
        }
    }

    public static class ShockEffect extends MobEffect {
        public ShockEffect() {
            super(MobEffectCategory.HARMFUL, 0x9FD8FF);
        }

        @Override
        public boolean applyEffectTick(LivingEntity entity, int amplifier) {
            if (!entity.level().isClientSide && entity.getHealth() > 2.0F) {
                entity.hurt(entity.damageSources().magic(), 1.0F + amplifier);
            }
            return true;
        }

        @Override
        public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
            return duration % 40 == 0;
        }
    }
}
