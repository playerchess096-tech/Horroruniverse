package com.horroruniverse.registry;

import com.horroruniverse.HorrorUniverse;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HorrorUniverse.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.horroruniverse"))
                    .icon(() -> new ItemStack(ModItems.PALE_FRAGMENT.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.PALE_FRAGMENT.get());
                        output.accept(ModItems.KEEPER_SIGIL.get());
                        output.accept(ModItems.RITUAL_EYE.get());
                        output.accept(ModItems.RITUAL_PEARL.get());
                        output.accept(ModItems.ELECTRIC_SCEPTER.get());
                        output.accept(ModItems.TRUTH_LENS.get());
                        output.accept(ModItems.EDEN_FRUIT.get());
                        output.accept(ModItems.PLAGUE_BLADE.get());
                        output.accept(ModItems.METEOR_BLADE.get());
                        output.accept(ModItems.LIGHTNING_BLADE.get());
                        output.accept(ModItems.PALE_BREAD.get());
                        output.accept(ModItems.MOON_APPLE.get());
                        output.accept(ModItems.RUNE_COOKIE.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
