package com.horroruniverse;

import com.horroruniverse.command.HorrorCommands;
import com.horroruniverse.config.HorrorConfig;
import com.horroruniverse.event.HorrorDirector;
import com.horroruniverse.registry.ModCreativeTabs;
import com.horroruniverse.registry.ModEffects;
import com.horroruniverse.registry.ModEntities;
import com.horroruniverse.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerWakeUpEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;

@Mod(HorrorUniverse.MODID)
public class HorrorUniverse {
    public static final String MODID = "horroruniverse";
    public static final Logger LOGGER = LogUtils.getLogger();

    public HorrorUniverse(IEventBus modBus, ModContainer container) {
        ModEffects.EFFECTS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        modBus.addListener(ModEntities::registerAttributes);

        container.registerConfig(ModConfig.Type.COMMON, HorrorConfig.SPEC);

        NeoForge.EVENT_BUS.addListener((RegisterCommandsEvent e) -> HorrorCommands.register(e.getDispatcher()));
        NeoForge.EVENT_BUS.addListener((ServerStartingEvent e) -> HorrorDirector.reset());
        NeoForge.EVENT_BUS.addListener((ServerStoppedEvent e) -> HorrorDirector.reset());
        NeoForge.EVENT_BUS.addListener((ServerTickEvent.Post e) -> HorrorDirector.onServerTick(e.getServer()));
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> HorrorDirector.onLogin(e.getEntity()));
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> HorrorDirector.onLogout(e.getEntity()));
        NeoForge.EVENT_BUS.addListener((LivingDeathEvent e) -> HorrorDirector.onDeath(e.getEntity()));
        NeoForge.EVENT_BUS.addListener((PlayerWakeUpEvent e) -> HorrorDirector.onWake(e.getEntity()));
        NeoForge.EVENT_BUS.addListener((BlockEvent.BreakEvent e) -> HorrorDirector.onBreak(e.getPlayer(), e.getState()));
    }
}
